import React, { useState } from 'react';
import { Image, View, type ImageSourcePropType } from 'react-native';
import Svg, { Defs, Image as SvgImage, Mask, RadialGradient, Rect, Stop } from 'react-native-svg';
import type { ArtFamily } from '../content/types';
import { useDesign } from './ThemeProvider';
import { radius, shadow } from './tokens';
import { Icon } from './Icon';

/** Bundled watercolor scenes (owner-approved design canvas art). Flat images, not layered production assets. */
export const artSources: Record<ArtFamily | 'closing-cafe', ImageSourcePropType> = {
  cafe: require('../../assets/art/cafe.jpg'),
  kitchen: require('../../assets/art/kitchen.jpg'),
  window: require('../../assets/art/window.jpg'),
  travel: require('../../assets/art/travel.jpg'),
  notebook: require('../../assets/art/notebook.jpg'),
  garden: require('../../assets/art/garden.jpg'),
  'closing-cafe': require('../../assets/art/closing-cafe.jpg'),
};

/** Where the crop sits inside the painting: an authored chapter state (handoff §48–51), never driven by speech. */
export type ArtFocus = 'center' | 'top-left' | 'right' | 'bottom' | 'left' | 'top';
const aspect: Record<ArtFocus, string> = {
  center: 'xMidYMid slice', 'top-left': 'xMinYMin slice', right: 'xMaxYMid slice', bottom: 'xMidYMax slice', left: 'xMinYMid slice', top: 'xMidYMin slice',
};
/** Chapter → crop. Prompts 1–5 then the closing; rapid navigation always resolves to the mapped state. */
export const chapterFocus: readonly ArtFocus[] = ['top-left', 'center', 'right', 'left', 'bottom', 'bottom'];

let featherId = 0;

/**
 * DS10 hero scene: the painting feathers into the page with no box ("painted edges").
 * Decorative: hidden from screen readers. Bleeds to the screen edges (pass the page inset).
 */
export function FeatheredArt({ source, height, focus = 'center', bleed = 24 }: { source: ImageSourcePropType; height: number; focus?: ArtFocus; bleed?: number }) {
  const [width, setWidth] = useState(0);
  const [id] = useState(() => `feather${featherId++}`);
  return <View accessible={false} importantForAccessibility="no-hide-descendants" accessibilityElementsHidden pointerEvents="none"
    style={{ height, marginHorizontal: -bleed }} onLayout={e => setWidth(e.nativeEvent.layout.width)}>
    {width > 0 ? <Svg width={width} height={height}>
      <Defs>
        <RadialGradient id={`${id}g`} cx="50%" cy="50%" rx="74%" ry="80%" fx="50%" fy="50%">
          <Stop offset="0.56" stopColor="#fff" stopOpacity="1" />
          <Stop offset="1" stopColor="#fff" stopOpacity="0" />
        </RadialGradient>
        <Mask id={`${id}m`} x="0" y="0" width={width} height={height} maskUnits="userSpaceOnUse">
          <Rect x="0" y="0" width={width} height={height} fill={`url(#${id}g)`} />
        </Mask>
      </Defs>
      <SvgImage href={source} x="0" y="0" width={width} height={height} preserveAspectRatio={aspect[focus]} mask={`url(#${id}m)`} />
    </Svg> : null}
  </View>;
}

/** Feathered art that keeps a warm-paper ground in dark mode ("Dark mode keeps art on its own warm paper"). */
export function SceneArt({ family, height, focus, source }: { family: ArtFamily; height: number; focus?: ArtFocus; source?: ImageSourcePropType }) {
  const { scheme, palette } = useDesign();
  const art = <FeatheredArt source={source ?? artSources[family]} height={height} focus={focus} />;
  if (scheme === 'light') return art;
  return <View style={{ marginHorizontal: -24, backgroundColor: palette.paper }}><View style={{ marginHorizontal: 24 }}>{art}</View></View>;
}

/** Small cropped art with a 10–12 pt corner and the one shadow (catalogue crop, theme tiles, Moment thumbs). */
export function ArtTile({ family, size, height, rounded = radius.art, missing = false }: { family?: ArtFamily; size: number; height?: number; rounded?: number; missing?: boolean }) {
  const { palette, scheme } = useDesign();
  const h = height ?? size;
  if (missing || !family) {
    return <View accessible={false} style={{ width: size, height: h, borderRadius: rounded, backgroundColor: palette.warm, alignItems: 'center', justifyContent: 'center' }}>
      <Icon name="book" color={palette.secondary} size={22} />
    </View>;
  }
  return <View accessible={false} importantForAccessibility="no-hide-descendants" style={[{ width: size, height: h, borderRadius: rounded, backgroundColor: palette.paper }, shadow(scheme)]}>
    <Image source={artSources[family]} accessible={false} resizeMode="cover" style={{ width: size, height: h, borderRadius: rounded }} />
  </View>;
}
