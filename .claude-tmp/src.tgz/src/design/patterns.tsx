import React from 'react';
import { Pressable, View } from 'react-native';
import type { Topic } from '../content/types';
import type { Attachment, Moment } from '../data/repository';
import { getTopic } from '../content/catalogue';
import { ArtTile } from './Art';
import { Icon } from './Icon';
import { Button, IconButton, StatusLine, TextBlock } from './primitives';
import { useDesign } from './ThemeProvider';
import { spacing } from './tokens';

export const durationShort = (minutes: number, language: 'en' | 'nl') => (language === 'nl' ? `Ongeveer ${minutes} min` : `About ${minutes} min`);
export const durationLong = (minutes: number, language: 'en' | 'nl') => (language === 'nl' ? `Ongeveer ${minutes} minuten` : `About ${minutes} minutes`);
export const intensityLabel = { light: { en: 'Light', nl: 'Luchtig' }, personal: { en: 'Personal', nl: 'Persoonlijk' }, direct: { en: 'Direct', nl: 'Direct' } } as const;

/** Access label: free / in your collection / locked collection. Text + symbol, never colour alone. */
export function AccessTag({ topic, owned }: { topic: Topic; owned: boolean }) {
  const { palette, t } = useDesign();
  const free = topic.access === 'free';
  const label = free ? t({ en: 'Free', nl: 'Gratis' }) : owned ? t({ en: 'In your collection', nl: 'In jouw collectie' }) : t({ en: 'Collection', nl: 'Collectie' });
  return <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
    <Icon name={free || owned ? 'check' : 'lock'} color={palette.text} size={14} />
    <TextBlock variant="supporting" style={{ fontWeight: '600' }}>{label}</TextBlock>
  </View>;
}

/** DS08 topic row: cover crop, title, invitation, duration · intensity, access, bookmark. */
export function TopicRow({ topic, owned, bookmarked, onOpen, onToggleBookmark }: {
  topic: Topic; owned: boolean; bookmarked: boolean; onOpen: () => void; onToggleBookmark: () => void;
}) {
  const { palette, language, t } = useDesign();
  const meta = `${durationShort(topic.minutes, language)} · ${t(intensityLabel[topic.intensity])}`;
  const free = topic.access === 'free';
  return <View style={{ flexDirection: 'row', gap: spacing.group, paddingVertical: spacing.group, borderBottomWidth: 1, borderBottomColor: palette.divider }}>
    <Pressable accessibilityRole="button" onPress={onOpen}
      accessibilityLabel={`${topic.title[language]}. ${topic.invitation[language]} ${meta}. ${free ? t({ en: 'Free', nl: 'Gratis' }) : owned ? t({ en: 'In your collection', nl: 'In jouw collectie' }) : t({ en: 'Collection', nl: 'Collectie' })}`}
      style={({ pressed }) => ({ flex: 1, flexDirection: 'row', gap: spacing.group, opacity: pressed ? 0.75 : 1 })}>
      <ArtTile family={topic.artFamily} size={64} />
      <View style={{ flex: 1, gap: 3 }}>
        <TextBlock variant="rowTitle">{topic.title[language]}</TextBlock>
        <TextBlock variant="meta" secondary>{topic.invitation[language]}</TextBlock>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', columnGap: 8, rowGap: 4, marginTop: 2 }}>
          <TextBlock variant="supporting" secondary>{meta}</TextBlock>
          <AccessTag topic={topic} owned={owned} />
        </View>
      </View>
    </Pressable>
    <View style={{ marginTop: -10, marginRight: -10 }}>
      <IconButton name="bookmark" filled={bookmarked} size={20} onPress={onToggleBookmark}
        label={bookmarked ? t({ en: `Remove ${topic.title.en} from saved`, nl: `${topic.title.nl} niet meer bewaren` }) : t({ en: 'Save for later', nl: 'Bewaar voor later' })} />
    </View>
  </View>;
}

export function formatClip(ms: number | null | undefined) {
  const s = Math.max(0, Math.round((ms ?? 0) / 1000));
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}

export function formatDay(iso: string, language: 'en' | 'nl') {
  return new Date(iso).toLocaleDateString(language === 'nl' ? 'nl-BE' : 'en-GB', { day: 'numeric', month: 'short' });
}

/** DS14 Moment row: thumb, title, date, saved words in italic (or "Voice note · 01:48"), source and save status. */
export function MomentRow({ moment, attachments, onOpen }: { moment: Moment; attachments: Attachment[]; onOpen: () => void }) {
  const { palette, language, t } = useDesign();
  const topic = getTopic(moment.topicId);
  const audio = attachments.find(a => a.momentId === moment.id && a.kind === 'audio');
  const isVoiceOnly = moment.source === 'audio' && !moment.body.trim();
  const preview = isVoiceOnly ? `${t({ en: 'Voice note', nl: 'Spraaknotitie' })} · ${formatClip(audio?.durationMs)}` : moment.body;
  return <Pressable accessibilityRole="button" onPress={onOpen} accessibilityLabel={`${moment.title}. ${formatDay(moment.createdAt, language)}. ${preview}`}
    style={({ pressed }) => ({ flexDirection: 'row', gap: spacing.group, paddingVertical: spacing.group, borderBottomWidth: 1, borderBottomColor: palette.divider, opacity: pressed ? 0.75 : 1 })}>
    <ArtTile family={topic?.artFamily} size={48} height={60} rounded={8} missing={!topic} />
    <View style={{ flex: 1, gap: 4 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: spacing.sm }}>
        <TextBlock variant="rowTitle" style={{ flex: 1 }}>{moment.title}</TextBlock>
        <TextBlock variant="supporting" secondary>{formatDay(moment.createdAt, language)}</TextBlock>
      </View>
      <TextBlock variant="voice" style={{ fontSize: 15, lineHeight: 22 }} numberOfLines={3}>{preview}</TextBlock>
      {moment.source === 'reviewed-ai' && <StatusLine icon="document" text={t({ en: 'AI draft, reviewed by you', nl: 'AI-voorstel, door jou nagekeken' })} tone="text" />}
      {topic && <StatusLine icon={moment.source === 'audio' ? 'mic' : moment.source === 'reviewed-ai' ? 'document' : 'pen'} text={topic.title[language]} />}
      <StatusLine icon="device" text={t({ en: 'Saved on this device', nl: 'Bewaard op dit apparaat' })} />
    </View>
  </Pressable>;
}

/** DS20 empty / recovery state: useful copy, optional art, one relevant action. */
export function EmptyState({ title, detail, action, art }: { title: string; detail: string; action?: { label: string; onPress: () => void }; art?: React.ReactNode }) {
  return <View style={{ alignItems: 'center', gap: spacing.group, paddingVertical: spacing.lg }}>
    {art}
    <TextBlock variant="title" center>{title}</TextBlock>
    <TextBlock variant="body" secondary center>{detail}</TextBlock>
    {action && <View style={{ alignSelf: 'stretch', alignItems: 'center' }}><View style={{ minWidth: 180 }}><Button variant="secondary" label={action.label} onPress={action.onPress} /></View></View>}
  </View>;
}
