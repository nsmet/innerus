import { Directory, File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { getTopic } from '../content/catalogue';
import type { Language } from '../content/types';
import type { Moment } from '../data/repository';

/**
 * Deliberate export of one Moment through the system share sheet (spec 21/37).
 * Writes a readable copy into the cache, shares it, then removes the temporary copy.
 * Nothing is uploaded by InnerUs; the destination receives a copy outside the app.
 */
export type ExportAttachment = { uri: string; kind: 'audio' | 'transcript' };
export type ExportWhat = 'text' | 'recording';
export type ExportResult = 'shared' | 'unavailable' | 'failed';

const labels = {
  topic: { en: 'Conversation', nl: 'Gesprek' },
  question: { en: 'Question', nl: 'Vraag' },
  date: { en: 'Date', nl: 'Datum' },
  source: { en: 'Source', nl: 'Bron' },
  typed: { en: 'Written by you', nl: 'Door jou geschreven' },
  'reviewed-ai': { en: 'AI draft, reviewed by you', nl: 'AI-voorstel, door jou nagekeken' },
  audio: { en: 'Voice note', nl: 'Spraaknotitie' },
  footer: { en: 'Exported from InnerUs.', nl: 'Geëxporteerd uit InnerUs.' },
} as const;

function exportFolder() {
  return new Directory(Paths.cache, 'innerus-export');
}

/** Removes leftovers from earlier exports (e.g. when the app closed during sharing). */
function clearExportFolder() {
  try {
    const folder = exportFolder();
    if (folder.exists) folder.delete();
  } catch { /* best effort */ }
}

function safeName(title: string) {
  const cleaned = title.replace(/[\\/:*?"<>|\n\r\t]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 60);
  return cleaned || 'InnerUs moment';
}

/** The readable text document: title, conversation, question, date, source, body. */
export function momentText(moment: Moment, language: Language) {
  const topic = getTopic(moment.topicId);
  const date = new Date(moment.createdAt).toLocaleDateString(language === 'nl' ? 'nl-BE' : 'en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  const lines = [moment.title, ''];
  if (topic) lines.push(`${labels.topic[language]}: ${topic.title[language]}`);
  if (moment.questionSnapshot) lines.push(`${labels.question[language]}: ${moment.questionSnapshot}`);
  lines.push(`${labels.date[language]}: ${date}`);
  lines.push(`${labels.source[language]}: ${labels[moment.source][language]}`);
  if (moment.body.trim()) lines.push('', moment.body);
  lines.push('', '—', labels.footer[language], '');
  return lines.join('\n');
}

export async function exportMoment(moment: Moment, attachments: ExportAttachment[], language: Language, what: ExportWhat = 'text'): Promise<ExportResult> {
  if (!(await Sharing.isAvailableAsync())) return 'unavailable';
  clearExportFolder();
  let copy: File | null = null;
  try {
    const folder = exportFolder();
    folder.create({ intermediates: true, idempotent: true });
    if (what === 'text') {
      copy = new File(folder, `${safeName(moment.title)}.txt`);
      copy.create({ overwrite: true });
      copy.writeSync(momentText(moment, language));
      await Sharing.shareAsync(copy.uri, { mimeType: 'text/plain', UTI: 'public.plain-text', dialogTitle: moment.title });
    } else {
      const audio = attachments.find(a => a.kind === 'audio');
      if (!audio) return 'failed';
      const source = new File(audio.uri);
      if (!source.exists) return 'failed';
      const extension = audio.uri.split('.').pop()?.split('?')[0] || 'm4a';
      copy = new File(folder, `${safeName(moment.title)}.${extension}`);
      source.copySync(copy);
      await Sharing.shareAsync(copy.uri, { mimeType: 'audio/mp4', UTI: 'public.mpeg-4-audio', dialogTitle: moment.title });
    }
    return 'shared';
  } catch {
    return 'failed';
  } finally {
    try { if (copy?.exists) copy.delete(); } catch { /* removed with the next export */ }
  }
}
