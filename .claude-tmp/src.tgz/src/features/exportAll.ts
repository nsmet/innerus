import { File, Paths } from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { getTopic } from '../content/catalogue';
import type { Language } from '../content/types';
import type { Attachment, Moment } from '../data/repository';

/**
 * "Export all" (spec 37): one readable .txt collection of every Moment, newest first, with topic, question,
 * date and source labels. Written to the cache, handed to the system share sheet only after the person
 * confirmed, then removed. Recordings stay in InnerUs; the text says which Moments have one.
 */
export type ExportResult = 'shared' | 'empty' | 'unavailable' | 'failed';

const labels = {
  en: {
    heading: 'InnerUs — your Moments',
    exported: 'Exported',
    count: (n: number) => (n === 1 ? '1 Moment' : `${n} Moments`),
    topic: 'Conversation',
    question: 'Question',
    date: 'Date',
    source: 'Source',
    typed: 'Written note',
    'reviewed-ai': 'AI draft, reviewed by you',
    audio: 'Voice note',
    recording: 'Recording: kept in InnerUs on this device (not included in this text export).',
    noText: '(No written text.)',
    unknownTopic: 'A conversation',
  },
  nl: {
    heading: 'InnerUs — jullie momenten',
    exported: 'Geëxporteerd',
    count: (n: number) => (n === 1 ? '1 moment' : `${n} momenten`),
    topic: 'Gesprek',
    question: 'Vraag',
    date: 'Datum',
    source: 'Bron',
    typed: 'Geschreven notitie',
    'reviewed-ai': 'AI-voorstel, door jou nagekeken',
    audio: 'Spraaknotitie',
    recording: 'Opname: bewaard in InnerUs op dit apparaat (niet in deze tekstexport).',
    noText: '(Geen geschreven tekst.)',
    unknownTopic: 'Een gesprek',
  },
} as const;

function longDate(iso: string, language: Language) {
  return new Date(iso).toLocaleDateString(language === 'nl' ? 'nl-BE' : 'en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
}

export function buildExportText(moments: readonly Moment[], attachments: readonly Attachment[], language: Language): string {
  const l = labels[language];
  const sorted = [...moments].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const withAudio = new Set(attachments.filter(a => a.kind === 'audio').map(a => a.momentId));
  const sections = sorted.map(moment => {
    const topic = getTopic(moment.topicId);
    const lines = [
      moment.title,
      '',
      `${l.topic}: ${topic ? topic.title[language] : l.unknownTopic}`,
      moment.questionSnapshot ? `${l.question}: ${moment.questionSnapshot}` : null,
      `${l.date}: ${longDate(moment.createdAt, language)}`,
      `${l.source}: ${l[moment.source]}`,
      withAudio.has(moment.id) ? l.recording : null,
      '',
      moment.body.trim() || l.noText,
    ];
    return lines.filter((line): line is string => line !== null).join('\n');
  });
  const header = `${l.heading}\n${l.exported}: ${longDate(new Date().toISOString(), language)} · ${l.count(sorted.length)}`;
  return [header, ...sections].join('\n\n————————————\n\n') + '\n';
}

/** Writes the collection, opens the share sheet, and deletes the temporary file afterwards. */
export async function shareAllMoments(moments: readonly Moment[], attachments: readonly Attachment[], language: Language): Promise<ExportResult> {
  if (moments.length === 0) return 'empty';
  let file: File | null = null;
  try {
    if (!(await Sharing.isAvailableAsync())) return 'unavailable';
    const day = new Date().toISOString().slice(0, 10);
    file = new File(Paths.cache, `InnerUs-${language === 'nl' ? 'momenten' : 'moments'}-${day}.txt`);
    if (file.exists) file.delete();
    file.create();
    await file.write(buildExportText(moments, attachments, language));
    await Sharing.shareAsync(file.uri, {
      mimeType: 'text/plain',
      UTI: 'public.plain-text',
      dialogTitle: language === 'nl' ? 'Momenten exporteren' : 'Export Moments',
    });
    return 'shared';
  } catch {
    return 'failed';
  } finally {
    try { if (file?.exists) file.delete(); } catch { /* the cache is cleared by the system */ }
  }
}
