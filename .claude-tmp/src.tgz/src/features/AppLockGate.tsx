import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, Platform, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as LocalAuthentication from 'expo-local-authentication';
import { Button, PaperGrain, StatusLine, TextBlock } from '../design/primitives';
import { useDesign } from '../design/ThemeProvider';
import { geometry, spacing, typography } from '../design/tokens';
import { useAppStore } from '../state/AppStore';

/** How long InnerUs may sit in the background before App lock asks again. */
const RELOCK_AFTER_MS = 30_000;

/** Whether the device has any security (biometrics or a passcode/PIN) that App lock can use. */
export async function deviceSecurityAvailable(): Promise<boolean> {
  try {
    const level = await LocalAuthentication.getEnrolledLevelAsync();
    return level !== LocalAuthentication.SecurityLevel.NONE;
  } catch {
    return false;
  }
}

/** One platform authentication (Face ID / fingerprint with the device passcode as fallback). */
export async function authenticateWithDevice(promptMessage: string, cancelLabel: string): Promise<boolean> {
  try {
    const result = await LocalAuthentication.authenticateAsync({ promptMessage, cancelLabel, disableDeviceFallback: false });
    return result.success;
  } catch {
    return false;
  }
}

/**
 * Optional App lock (spec 36): an operating-system privacy control, not an InnerUs account.
 * On a cold start the app content is not rendered until unlocked. After more than 30 s in the background
 * the content is covered (kept mounted so nobody loses their place) and hidden from assistive technology.
 */
export function AppLockGate({ children }: React.PropsWithChildren) {
  const { prefs, setPref } = useAppStore();
  const { palette, t } = useDesign();
  const [locked, setLocked] = useState(prefs.appLock);
  const [unlockedOnce, setUnlockedOnce] = useState(!prefs.appLock);
  const [inBackground, setInBackground] = useState(false);
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useState(false);
  const backgroundAt = useRef<number | null>(null);
  const lockOn = useRef(prefs.appLock);
  lockOn.current = prefs.appLock;

  useEffect(() => {
    const sub = AppState.addEventListener('change', state => {
      if (state === 'background') {
        backgroundAt.current = Date.now();
        setInBackground(true);
      } else if (state === 'active') {
        setInBackground(false);
        const since = backgroundAt.current;
        backgroundAt.current = null;
        if (lockOn.current && since !== null && Date.now() - since > RELOCK_AFTER_MS) {
          setFailed(false);
          setLocked(true);
        }
      }
    });
    return () => sub.remove();
  }, []);

  // Turning the preference off in Settings releases the gate.
  useEffect(() => {
    if (!prefs.appLock) { setLocked(false); setUnlockedOnce(true); }
  }, [prefs.appLock]);

  const unlock = useCallback(async () => {
    setBusy(true);
    setFailed(false);
    if (!(await deviceSecurityAvailable())) {
      // Device security was removed: the lock cannot work any more, so it is switched off.
      await setPref('appLock', false);
      setBusy(false);
      return;
    }
    const ok = await authenticateWithDevice(
      t({ en: 'Unlock InnerUs', nl: 'Ontgrendel InnerUs' }),
      t({ en: 'Cancel', nl: 'Annuleren' }),
    );
    setBusy(false);
    if (ok) { setLocked(false); setUnlockedOnce(true); } else setFailed(true);
  }, [setPref, t]);

  const showCover = prefs.appLock && (locked || inBackground);
  const renderChildren = unlockedOnce;

  return <View style={{ flex: 1 }}>
    {renderChildren ? <View style={{ flex: 1 }} importantForAccessibility={showCover ? 'no-hide-descendants' : 'auto'} accessibilityElementsHidden={showCover}>
      {children}
    </View> : null}
    {showCover ? <View style={[StyleSheet.absoluteFill, { backgroundColor: palette.canvas }]}>
      <PaperGrain />
      <SafeAreaView style={{ flex: 1 }}>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.page, paddingHorizontal: spacing.page, maxWidth: geometry.contentMax, width: '100%', alignSelf: 'center' }}>
          <TextBlock variant="display" center accessibilityRole="header">
            Inner<TextBlock variant="display" style={{ fontFamily: typography.invitation.fontFamily }}>Us</TextBlock>
          </TextBlock>
          <TextBlock variant="body" secondary center>
            {Platform.OS === 'ios'
              ? t({ en: 'App lock is on. Use Face ID or your passcode to continue.', nl: 'App-vergrendeling staat aan. Gebruik Face ID of je toegangscode om verder te gaan.' })
              : t({ en: 'App lock is on. Use your fingerprint, face or screen lock to continue.', nl: 'App-vergrendeling staat aan. Gebruik je vingerafdruk, gezicht of schermvergrendeling om verder te gaan.' })}
          </TextBlock>
          {locked ? <View style={{ alignSelf: 'stretch', gap: spacing.md }}>
            <Button label={t({ en: 'Unlock', nl: 'Ontgrendelen' })} icon="lock" loading={busy} onPress={() => { void unlock(); }} />
            {failed ? <View style={{ alignItems: 'center' }}>
              <StatusLine icon="warning" text={t({ en: 'Not unlocked. Try again when you are ready.', nl: 'Niet ontgrendeld. Probeer opnieuw wanneer je klaar bent.' })} />
            </View> : null}
          </View> : null}
        </View>
      </SafeAreaView>
    </View> : null}
  </View>;
}
