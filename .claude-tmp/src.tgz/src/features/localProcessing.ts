import { probeCapabilities, type Capability, type CapabilityState } from '../../modules/innerus-platform';

/**
 * Honest local speech/summary capability layer (spec 25–29).
 *
 * The platform adapter can only PROBE availability today. There is no transcription or summary
 * execution adapter in this build, so `canTranscribe` stays false and `transcribe()` / `summarize()`
 * always report 'not-available'. Nothing here ever calls a network or cloud service, and nothing
 * ever invents text.
 */
export type LocalState = 'ready' | 'needs-download' | 'unsupported';

export type LocalProcessing = {
  transcription: LocalState;
  summary: LocalState;
  /** True only when the probe says ready AND this build can actually run local transcription. */
  canTranscribe: boolean;
  /** True only when the probe says ready AND this build can actually run a local summary. */
  canSummarize: boolean;
};

/** Execution adapters present in this build. Flip only when a real on-device adapter ships. */
const TRANSCRIPTION_ADAPTER = false;
const SUMMARY_ADAPTER = false;

function toLocal(state: CapabilityState): LocalState {
  if (state === 'ready') return 'ready';
  if (state === 'needs-download' || state === 'downloading') return 'needs-download';
  return 'unsupported';
}

function stateFor(capability: Capability, languageTag: string): LocalState {
  return toLocal(capability.languages?.[languageTag] ?? capability.state);
}

/** Checks what this device can do for one recording language. Never throws. */
export async function getLocalProcessing(languageTag: string): Promise<LocalProcessing> {
  try {
    const report = await probeCapabilities([languageTag]);
    const transcription = stateFor(report.transcription, languageTag);
    const summary = stateFor(report.summary, languageTag);
    return {
      transcription,
      summary,
      canTranscribe: TRANSCRIPTION_ADAPTER && transcription === 'ready',
      canSummarize: SUMMARY_ADAPTER && summary === 'ready',
    };
  } catch {
    return { transcription: 'unsupported', summary: 'unsupported', canTranscribe: false, canSummarize: false };
  }
}

export type TranscribeResult =
  | { ok: true; text: string }
  | { ok: false; reason: 'not-available' | 'no-speech' | 'cancelled' | 'failed' };

export type SummaryResult =
  | { ok: true; title: string; paragraph: string }
  | { ok: false; reason: 'not-available' | 'cancelled' | 'failed' };

export type ProcessingOptions = { languageTag: string; onProgress?: (fraction: number) => void; signal?: AbortSignal };

/** Local transcription of one recorded clip. Not available in this build: never fakes text. */
export async function transcribe(_uri: string, _options: ProcessingOptions): Promise<TranscribeResult> {
  return { ok: false, reason: 'not-available' };
}

/**
 * Local short memory from one transcript, its question and the topic title only (spec 27).
 * Not available in this build: never fakes text.
 */
export async function summarize(_input: { transcript: string; question: string | null; topicTitle: string }, _options: ProcessingOptions): Promise<SummaryResult> {
  return { ok: false, reason: 'not-available' };
}
