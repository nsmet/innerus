import React from 'react';
import { Platform, View } from 'react-native';
import type { Localized } from '../content/types';
import { Icon, type IconName } from '../design/Icon';
import { BackHeader, Divider, Screen, TextBlock } from '../design/primitives';
import { useDesign } from '../design/ThemeProvider';
import { spacing } from '../design/tokens';
import type { StackProps } from '../navigation/types';

/** Offline help (spec 11/30/35): bundled with the app, no web view, no network. */
type Section = { icon: IconName; eyebrow: Localized; title: Localized; body: Localized[] };

const ios = Platform.OS === 'ios';
const device: Localized = ios ? { en: 'this iPhone', nl: 'deze iPhone' } : { en: 'this device', nl: 'dit apparaat' };
const on = (text: (d: string) => string, textNl: (d: string) => string): Localized => ({ en: text(device.en), nl: textNl(device.nl) });

const how: { title: Localized; intro: Localized; sections: Section[] } = {
  title: { en: 'How this works', nl: 'Zo werkt het' },
  intro: {
    en: 'InnerUs gives the two of you a calm place for good conversations. Here is what it does, and what it never does.',
    nl: 'InnerUs geeft jullie samen een rustige plek voor goede gesprekken. Dit is wat het doet, en wat het nooit doet.',
  },
  sections: [
    {
      icon: 'shield', eyebrow: { en: 'No account', nl: 'Geen account' }, title: { en: 'Just open it and start', nl: 'Gewoon openen en beginnen' },
      body: [{ en: 'There is no InnerUs account, no sign-up and no email address. InnerUs never asks for names, dates, contacts, photos or your location.', nl: 'Er is geen InnerUs-account, geen registratie en geen e-mailadres. InnerUs vraagt nooit om namen, datums, contacten, foto’s of je locatie.' }],
    },
    {
      icon: 'book', eyebrow: { en: 'Conversations', nl: 'Gesprekken' }, title: { en: 'Written ahead, inside the app', nl: 'Vooraf geschreven, in de app' },
      body: [
        { en: 'Every conversation is written by people and comes with the app, so it works offline.', nl: 'Elk gesprek is door mensen geschreven en zit in de app, dus het werkt ook offline.' },
        { en: 'Nothing advances on its own. You choose when to go a little further, skip a question or stop. There are no timers and no scores.', nl: 'Niets gaat vanzelf verder. Jullie kiezen wanneer je een stukje verder gaat, een vraag overslaat of stopt. Er zijn geen timers en geen scores.' },
      ],
    },
    {
      icon: 'pen', eyebrow: { en: 'Moments', nl: 'Momenten' }, title: { en: 'Only what you choose to keep', nl: 'Alleen wat jullie willen bewaren' },
      body: [{ en: 'Keeping a moment is always optional. A conversation is complete without saving anything.', nl: 'Een moment bewaren is altijd optioneel. Een gesprek is compleet, ook als je niets bewaart.' }],
    },
    {
      icon: 'mic', eyebrow: { en: 'Recording', nl: 'Opnemen' }, title: { en: 'Only when you press record', nl: 'Alleen als jij op opnemen drukt' },
      body: [
        { en: 'InnerUs asks for the microphone only when you choose to record an answer, and never records by itself.', nl: 'InnerUs vraagt de microfoon pas als jij kiest om een antwoord op te nemen, en neemt nooit vanzelf op.' },
        on(d => `Turning speech into text and making a short draft memory happen on ${d}, when it supports it. Your words are not sent anywhere for processing.`, d => `Spraak omzetten naar tekst en een korte herinnering voorstellen gebeurt op ${d}, als dat wordt ondersteund. Je woorden worden nergens naartoe gestuurd om verwerkt te worden.`),
      ],
    },
    {
      icon: 'share', eyebrow: { en: 'Export', nl: 'Exporteren' }, title: { en: 'Your own copy, when you want it', nl: 'Je eigen kopie, wanneer je wilt' },
      body: [{ en: 'Export creates a copy outside InnerUs through the share sheet. You choose where it goes.', nl: 'Exporteren maakt via het deelmenu een kopie buiten InnerUs. Jij kiest waar die naartoe gaat.' }],
    },
    {
      icon: 'help', eyebrow: { en: 'Contact', nl: 'Contact' }, title: { en: 'Questions or ideas', nl: 'Vragen of ideeën' },
      body: [{
        en: `Contact us via the InnerUs page in ${ios ? 'the App Store' : 'Google Play'}. Nothing from the app is sent with it unless you choose to add it yourself.`,
        nl: `Neem contact op via de InnerUs-pagina in ${ios ? 'de App Store' : 'Google Play'}. Er wordt niets uit de app meegestuurd, tenzij je dat zelf toevoegt.`,
      }],
    },
  ],
};

const data: { title: Localized; intro: Localized; sections: Section[] } = {
  title: { en: 'Where your data goes', nl: 'Waar je gegevens naartoe gaan' },
  intro: {
    en: 'InnerUs has no account and no server for your personal content. This is where everything lives.',
    nl: 'InnerUs heeft geen account en geen server voor je persoonlijke inhoud. Hier staat alles.',
  },
  sections: [
    {
      icon: 'device', eyebrow: on(d => `On ${d}`, d => `Op ${d}`), title: { en: 'Everything personal stays here', nl: 'Alles wat persoonlijk is blijft hier' },
      body: [
        { en: 'The conversations themselves, where you are in a conversation, unsaved drafts, your Moments and notes, and any recordings you chose to keep.', nl: 'De gesprekken zelf, waar jullie in een gesprek zijn, niet-bewaarde concepten, jullie momenten en notities, en opnames die je koos te bewaren.' },
        { en: 'This private storage is kept out of automatic device backups, so it does not leave through a backup either.', nl: 'Deze privé-opslag valt buiten automatische back-ups van het toestel, dus ook zo gaat er niets weg.' },
        { en: 'Recording drafts expire after 24 hours and are removed at the next app cleanup.', nl: 'Opnameconcepten vervallen na 24 uur en worden bij de volgende opruiming in de app verwijderd.' },
      ],
    },
    ...(ios ? [{
      icon: 'cloudOff' as IconName, eyebrow: { en: 'Not used in this version', nl: 'Niet gebruikt in deze versie' }, title: { en: 'iCloud sync', nl: 'iCloud-synchronisatie' },
      body: [{
        en: 'This version does not sync with iCloud yet. Your Moments will not appear on another device. Export keeps an independent copy.',
        nl: 'Deze versie synchroniseert nog niet met iCloud. Je momenten verschijnen niet op een ander toestel. Exporteren bewaart een losse kopie.',
      }],
    }] : [{
      icon: 'cloudOff' as IconName, eyebrow: { en: 'Local only', nl: 'Alleen lokaal' }, title: { en: 'No cloud sync on Android', nl: 'Geen cloudsynchronisatie op Android' },
      body: [{ en: 'Local-only storage. Export anything you want an independent copy of.', nl: 'Alleen lokale opslag. Exporteer wat je als losse kopie wilt bewaren.' }],
    }]),
    {
      icon: 'globe', eyebrow: { en: 'Platform services', nl: 'Platformdiensten' }, title: { en: 'What the store handles', nl: 'Wat de winkel regelt' },
      body: [
        { en: `${ios ? 'Apple' : 'Google'} handles purchases and app updates, and any optional speech or language downloads the system offers. Those services do not receive your Moments, notes or recordings.`, nl: `${ios ? 'Apple' : 'Google'} regelt aankopen en app-updates, en eventuele optionele spraak- of taaldownloads van het systeem. Die diensten krijgen je momenten, notities of opnames niet.` },
        { en: 'Your personal content is never sent anywhere for processing. There is no analytics or advertising tracking, and reminders never mention a topic or an answer.', nl: 'Je persoonlijke inhoud wordt nooit ergens naartoe gestuurd om verwerkt te worden. Er is geen analyse- of advertentietracking, en herinneringen noemen nooit een onderwerp of antwoord.' },
      ],
    },
    {
      icon: 'share', eyebrow: { en: 'When you choose', nl: 'Wanneer jij kiest' }, title: { en: 'Exports', nl: 'Exports' },
      body: [{ en: 'Something leaves InnerUs only when you export or share it yourself. Exports create a copy outside InnerUs that the app can no longer remove.', nl: 'Iets verlaat InnerUs alleen als je het zelf exporteert of deelt. Een export maakt een kopie buiten InnerUs die de app niet meer kan verwijderen.' }],
    },
  ],
};

export function HelpScreen({ navigation, route }: StackProps<'Help'>) {
  const { palette, t } = useDesign();
  const content = route.params.topic === 'data' ? data : how;
  const state = navigation.getState();
  const previous = state.routes[state.index - 1]?.name;
  const backLabel = previous === 'Settings' ? t({ en: 'Settings', nl: 'Instellingen' }) : t({ en: 'Back', nl: 'Terug' });

  return <Screen header={<BackHeader label={backLabel} onBack={() => navigation.goBack()} />}>
    <View style={{ gap: spacing.md, marginTop: spacing.sm }}>
      <TextBlock variant="display">{t(content.title)}</TextBlock>
      <TextBlock variant="invitation" secondary>{t(content.intro)}</TextBlock>
    </View>
    {content.sections.map((section, index) => <View key={section.eyebrow.en} style={{ gap: spacing.md }}>
      {index > 0 ? <Divider /> : null}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
        <Icon name={section.icon} color={palette.secondary} size={16} />
        <TextBlock variant="eyebrow" secondary style={{ flexShrink: 1 }}>{t(section.eyebrow)}</TextBlock>
      </View>
      <TextBlock variant="heading">{t(section.title)}</TextBlock>
      {section.body.map(paragraph => <TextBlock key={paragraph.en} variant="body">{t(paragraph)}</TextBlock>)}
    </View>)}
  </Screen>;
}
