import React, { useEffect, useState } from 'react';
import { Platform, View } from 'react-native';
import { themes, topics } from '../content/catalogue';
import type { Language } from '../content/types';
import { SceneArt } from '../design/Art';
import { Icon, type IconName } from '../design/Icon';
import { Button, Divider, Eyebrow, IconButton, Screen, StatusLine, TextBlock } from '../design/primitives';
import { useDesign } from '../design/ThemeProvider';
import { spacing, typography } from '../design/tokens';
import type { StackProps } from '../navigation/types';
import { checkCollectionOwnership, fetchCollectionProduct, purchaseCollection, restoreCollection, type CollectionProduct } from '../platform/store';
import { useAppStore } from '../state/AppStore';

/** UI11 collection offer (design Paywall + Paywall-states, DS23). The price always comes from the store. */
type Status = { icon: IconName; text: string; tone?: 'secondary' | 'text' | 'destructive' } | null;

function joinTitles(titles: string[], language: Language) {
  if (titles.length < 2) return titles.join('');
  return `${titles.slice(0, -1).join(', ')} ${language === 'nl' ? 'en' : 'and'} ${titles[titles.length - 1]}`;
}

export function PaywallScreen({ navigation }: StackProps<'Paywall'>) {
  const { palette, t, language } = useDesign();
  const { entitlement, setEntitlement } = useAppStore();
  const [product, setProduct] = useState<CollectionProduct | 'loading'>('loading');
  const [buying, setBuying] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [status, setStatus] = useState<Status>(null);

  useEffect(() => {
    let alive = true;
    void fetchCollectionProduct().then(result => { if (alive) setProduct(result); });
    return () => { alive = false; };
  }, []);

  const paid = topics.filter(topic => topic.access === 'collection');
  const free = topics.filter(topic => topic.access === 'free').map(topic => topic.title[language]);
  const storeName = Platform.OS === 'ios' ? 'App Store' : 'Google Play';

  const messages = {
    pending: { icon: 'clock', text: t({ en: 'Your purchase is pending. Free conversations remain available.', nl: 'Je aankoop is in behandeling. Gratis gesprekken blijven beschikbaar.' }) },
    failed: { icon: 'warning', text: t({ en: 'The purchase did not complete. You have not lost your place.', nl: 'De aankoop is niet afgerond. Je kunt verder waar je was.' }) },
    owned: { icon: 'check', text: t({ en: 'You already own this collection.', nl: 'Je hebt deze collectie al.' }), tone: 'text' },
    earlier: { icon: 'star', text: t({ en: 'We found an earlier purchase. You will not be charged again for what you already own.', nl: 'We vonden een eerdere aankoop. Je betaalt niet opnieuw voor wat je al hebt.' }), tone: 'text' },
    restored: { icon: 'refresh', text: t({ en: 'Purchases restored. Your conversations are ready.', nl: 'Aankopen hersteld. Je gesprekken staan klaar.' }), tone: 'text' },
    nothing: { icon: 'refresh', text: t({ en: `No earlier purchase was found for this ${Platform.OS === 'ios' ? 'Apple Account' : 'Google account'}.`, nl: `Er is geen eerdere aankoop gevonden voor dit ${Platform.OS === 'ios' ? 'Apple-account' : 'Google-account'}.` }) },
    unreachable: { icon: 'warning', text: t({ en: 'The store could not be reached. Try again later.', nl: 'De winkel is niet bereikbaar. Probeer het later opnieuw.' }) },
  } satisfies Record<string, NonNullable<Status>>;

  async function buy() {
    setBuying(true);
    setStatus(null);
    const outcome = await purchaseCollection();
    if (outcome === 'purchased') {
      setEntitlement({ owned: true, checked: true });
      setBuying(false);
      navigation.goBack(); // back to the topic the person came from, which now opens
      return;
    }
    if (outcome === 'owned') {
      // The store says this account already owns it: confirm from the store's own records before unlocking.
      const check = await checkCollectionOwnership();
      if (check === 'owned') { setEntitlement({ owned: true, checked: true }); setStatus(messages.earlier); }
      else setStatus(messages.failed);
    } else if (outcome === 'pending') setStatus(messages.pending);
    else if (outcome === 'unavailable') setStatus(messages.unreachable);
    else setStatus(messages.failed);
    setBuying(false);
  }

  async function restore() {
    setRestoring(true);
    setStatus(null);
    const outcome = await restoreCollection();
    if (outcome === 'restored') { setEntitlement({ owned: true, checked: true }); setStatus(messages.restored); }
    else setStatus(outcome === 'nothing' ? messages.nothing : messages.unreachable);
    setRestoring(false);
  }

  const priceReady = product !== 'loading' && product.status === 'ready';
  const unavailableReason = t({ en: 'The price isn’t available right now.', nl: 'De prijs is nu niet beschikbaar.' });

  const priceRow = product === 'loading'
    ? <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm, minHeight: 48, borderRadius: 8, backgroundColor: palette.warm }} accessible accessibilityLabel={t({ en: 'Getting the price…', nl: 'De prijs ophalen…' })}>
      <Icon name="clock" color={palette.secondary} size={16} />
      <TextBlock variant="label" secondary>{t({ en: 'Getting the price…', nl: 'De prijs ophalen…' })}</TextBlock>
    </View>
    : product.status === 'ready'
      ? <View style={{ flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', gap: spacing.md, flexWrap: 'wrap' }}>
        <TextBlock variant="display" style={{ fontSize: 30, lineHeight: 36 }}>{product.displayPrice}</TextBlock>
        <TextBlock variant="supporting" secondary style={{ flexShrink: 1, textAlign: 'right' }}>
          {t({ en: `One-time · price from ${storeName}`, nl: `Eenmalig · prijs van ${storeName}` })}
        </TextBlock>
      </View>
      : null;

  const owned = entitlement.owned;

  return <Screen
    header={<View style={{ alignItems: 'flex-end', marginTop: spacing.sm, marginRight: -10 }}>
      <IconButton name="close" label={t({ en: 'Close', nl: 'Sluiten' })} onPress={() => navigation.goBack()} />
    </View>}
    footer={<View style={{ gap: spacing.md }}>
      <Divider />
      {owned ? null : priceRow}
      {status ? <StatusLine icon={status.icon} text={status.text} tone={status.tone ?? 'secondary'} /> : null}
      {owned
        ? <Button label={t({ en: 'Continue', nl: 'Verder' })} onPress={() => navigation.goBack()} />
        : <Button label={t({ en: 'Get the collection', nl: 'Neem de collectie' })} onPress={() => { void buy(); }}
          loading={buying} loadingLabel={t({ en: 'Waiting for the store…', nl: 'Wachten op de winkel…' })}
          disabled={!priceReady || restoring} reason={product !== 'loading' && !priceReady ? unavailableReason : undefined} />}
      {owned ? null : <Button variant="quiet" label={t({ en: 'Restore purchases', nl: 'Herstel aankopen' })} onPress={() => { void restore(); }}
        loading={restoring} disabled={buying} />}
    </View>}>
    <View accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
      <SceneArt family="window" height={110} />
    </View>
    <View style={{ gap: spacing.sm, alignItems: 'center' }}>
      <Eyebrow framed>{t({ en: 'The collection', nl: 'De collectie' })}</Eyebrow>
      <TextBlock variant="display" center>{t({ en: 'Twelve more conversations', nl: 'Twaalf extra gesprekken' })}</TextBlock>
      <TextBlock variant="invitation" secondary center>{t({ en: 'One payment for 12 additional conversations.', nl: 'Een betaling voor 12 extra gesprekken.' })}</TextBlock>
    </View>
    {owned ? <StatusLine icon="check" tone="text" text={messages.owned.text} /> : null}
    <Divider />
    {themes.map(theme => {
      const list = paid.filter(topic => topic.theme === theme.id);
      if (!list.length) return null;
      return <View key={theme.id} style={{ gap: spacing.xs }} accessible accessibilityLabel={`${t(theme.label)}: ${list.map(topic => topic.title[language]).join(', ')}`}>
        <TextBlock variant="eyebrow" secondary>{t(theme.label)}</TextBlock>
        {list.map(topic => <View key={topic.id} style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingVertical: 2 }}>
          <Icon name="check" color={palette.text} size={16} />
          <TextBlock variant="body" style={{ fontFamily: typography.rowTitle.fontFamily, flexShrink: 1 }}>{topic.title[language]}</TextBlock>
        </View>)}
      </View>;
    })}
    <TextBlock variant="supporting" secondary>
      {t({
        en: `${joinTitles(free, 'en')} stay free. Recording, Moments, export and deletion are never part of a payment.`,
        nl: `${joinTitles(free, 'nl')} blijven gratis. Opnemen, momenten, exporteren en verwijderen zijn nooit onderdeel van een betaling.`,
      })}
    </TextBlock>
  </Screen>;
}
