import React, { useState } from 'react';
import { Platform, Pressable, TextInput, View } from 'react-native';
import { getTopic } from '../content/catalogue';
import type { Language } from '../content/types';
import { Icon } from '../design/Icon';
import { EmptyState } from '../design/patterns';
import {
  BackHeader, Button, Divider, Eyebrow, IconButton, NoteField, Screen, Sheet, SheetBadge, StatusLine, TextBlock,
} from '../design/primitives';
import { useDesign } from '../design/ThemeProvider';
import { geometry, radius, shadow, spacing, typography } from '../design/tokens';
import { AudioPlayer } from '../features/AudioPlayer';
import { exportMoment, type ExportWhat } from '../features/exportMoment';
import type { StackProps } from '../navigation/types';
import { useAppStore } from '../state/AppStore';

const languageNames: Record<Language, { en: string; nl: string }> = {
  en: { en: 'English', nl: 'Engels' },
  nl: { en: 'Dutch', nl: 'Nederlands' },
};

const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

/** UI10 Moment detail: saved words exactly as kept, question, retained audio, edit / export / delete (spec 21/33/37). */
export function MomentDetailScreen({ route, navigation }: StackProps<'MomentDetail'>) {
  const { palette, scheme, t, language } = useDesign();
  const { moments, attachments, updateMoment, deleteMoment, removeAttachment, attachmentUri } = useAppStore();
  const moment = moments.find(m => m.id === route.params.momentId);
  const audio = attachments.find(a => a.momentId === route.params.momentId && a.kind === 'audio');

  const [editing, setEditing] = useState(false);
  const [baseVersion, setBaseVersion] = useState(0);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [saving, setSaving] = useState(false);
  const [editError, setEditError] = useState<'conflict' | 'failed' | null>(null);
  const [sheet, setSheet] = useState<'export' | 'deleteMoment' | 'deleteAudio' | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [deleted, setDeleted] = useState(false);

  const device = Platform.OS === 'ios' ? { en: 'this iPhone', nl: 'deze iPhone' } : { en: 'this device', nl: 'dit apparaat' };
  const back = () => navigation.goBack();
  const backLabel = t({ en: 'Moments', nl: 'Momenten' });

  if (deleted) return <Screen>{null}</Screen>;
  if (!moment) {
    return <Screen header={<BackHeader label={backLabel} onBack={back} />}>
      <EmptyState title={t({ en: 'This moment is no longer here.', nl: 'Dit moment is er niet meer.' })}
        detail={t({ en: 'It may have been deleted.', nl: 'Het is misschien verwijderd.' })}
        action={{ label: backLabel, onPress: back }} />
    </Screen>;
  }

  const topic = getTopic(moment.topicId);
  const questionNumber = moment.promptId ? Number.parseInt(moment.promptId.split('-').pop() ?? '', 10) : NaN;
  const eyebrow = [topic?.title[language], Number.isFinite(questionNumber) ? `${t({ en: 'Question', nl: 'Vraag' })} ${questionNumber}` : null].filter(Boolean).join(' · ');
  const date = new Date(moment.createdAt).toLocaleDateString(language === 'nl' ? 'nl-BE' : 'en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  const meta = `${date} · ${t(languageNames[moment.contentLanguage] ?? languageNames.en)}`;

  const startEdit = () => {
    setTitle(moment.title);
    setBody(moment.body);
    setBaseVersion(moment.version);
    setEditError(null);
    setEditing(true);
  };

  const saveEdit = async () => {
    setSaving(true);
    setEditError(null);
    try {
      await updateMoment(moment.id, baseVersion, { title: title.trim(), body });
      setEditing(false);
      setNotice(t({ en: `Saved on ${device.en}`, nl: `Bewaard op ${device.nl}` }));
    } catch (error) {
      const message = error instanceof Error ? error.message : '';
      setEditError(message.includes('changed elsewhere') ? 'conflict' : 'failed');
    } finally {
      setSaving(false);
    }
  };

  const confirmDeleteMoment = async () => {
    setBusy(true);
    try {
      await deleteMoment(moment.id);
      setSheet(null);
      setDeleted(true);
      navigation.goBack();
    } catch {
      setBusy(false);
      setSheet(null);
      setNotice(t({ en: 'This moment could not be deleted. Please try again.', nl: 'Dit moment kon niet worden verwijderd. Probeer het opnieuw.' }));
    }
  };

  const confirmDeleteAudio = async () => {
    if (!audio) return;
    setBusy(true);
    try {
      await removeAttachment(audio);
      setNotice(t({ en: 'The recording was deleted. Your written note stays.', nl: 'De opname is verwijderd. Je geschreven notitie blijft.' }));
    } catch {
      setNotice(t({ en: 'The recording could not be deleted. Please try again.', nl: 'De opname kon niet worden verwijderd. Probeer het opnieuw.' }));
    } finally {
      setBusy(false);
      setSheet(null);
    }
  };

  const runExport = async (what: ExportWhat) => {
    setSheet(null);
    await wait(350); // let the sheet close before the system share sheet appears
    const result = await exportMoment(moment, audio ? [{ uri: attachmentUri(audio), kind: 'audio' }] : [], language, what);
    if (result === 'unavailable') setNotice(t({ en: 'Sharing is not available on this device.', nl: 'Delen is niet beschikbaar op dit apparaat.' }));
    if (result === 'failed') setNotice(t({ en: 'The export could not be prepared. Please try again.', nl: 'De export kon niet worden voorbereid. Probeer het opnieuw.' }));
  };

  const sourceLine = moment.source === 'reviewed-ai'
    ? <StatusLine icon="document" tone="text" text={t({ en: 'AI draft, reviewed by you', nl: 'AI-voorstel, door jou nagekeken' })} />
    : moment.source === 'audio'
      ? <StatusLine icon="mic" tone="text" text={t({ en: 'Voice note', nl: 'Spraaknotitie' })} />
      : null;

  const header = <BackHeader label={backLabel} onBack={back}
    right={!editing && <IconButton name="share" label={t({ en: 'Export', nl: 'Exporteren' })} onPress={() => setSheet('export')} />} />;

  const footer = editing
    ? <>
      <Button label={t({ en: 'Save', nl: 'Bewaren' })} icon="check" onPress={() => void saveEdit()} loading={saving}
        disabled={!title.trim()} reason={t({ en: 'Give this moment a title.', nl: 'Geef dit moment een titel.' })} />
      <Button variant="secondary" label={t({ en: 'Cancel', nl: 'Annuleren' })} onPress={() => { setEditing(false); setEditError(null); }} disabled={saving} />
    </>
    : <>
      <Button variant="secondary" icon="pen" label={t({ en: 'Edit', nl: 'Bewerken' })} onPress={startEdit} />
      <Button variant="secondary" icon="share" label={t({ en: 'Export', nl: 'Exporteren' })} onPress={() => setSheet('export')} />
      <Button variant="destructive" icon="trash" label={t({ en: 'Delete this moment', nl: 'Verwijder dit moment' })} onPress={() => setSheet('deleteMoment')} />
    </>;

  return <Screen header={header} footer={footer}>
    {eyebrow ? <Eyebrow>{eyebrow}</Eyebrow> : null}

    {editing ? <View style={{ gap: spacing.md }}>
      <TextInput value={title} onChangeText={setTitle} accessibilityLabel={t({ en: 'Title', nl: 'Titel' })}
        placeholder={t({ en: 'Title', nl: 'Titel' })} placeholderTextColor={palette.secondary}
        autoCorrect={false} spellCheck={false} autoComplete="off" importantForAutofill="no"
        style={[typography.heading, { color: palette.text, borderWidth: 1, borderColor: palette.outline, borderRadius: radius.control, paddingHorizontal: 14, paddingVertical: 10, minHeight: geometry.button }]} />
      <NoteField value={body} onChangeText={setBody} label={t({ en: 'Your note', nl: 'Je notitie' })}
        placeholder={t({ en: 'A detail, a thought, a small idea...', nl: 'Een detail, een gedachte, een klein idee...' })} minHeight={180} />
      {editError === 'conflict' && <View style={{ gap: spacing.sm }}>
        <StatusLine icon="warning" tone="text" text={t({
          en: 'This moment changed elsewhere. Your edit is still here.',
          nl: 'Dit moment is ergens anders gewijzigd. Je bewerking staat er nog.',
        })} />
        <Button variant="quiet" icon="refresh" label={t({ en: 'Start again from the saved version', nl: 'Begin opnieuw vanaf de bewaarde versie' })} onPress={startEdit} />
      </View>}
      {editError === 'failed' && <StatusLine icon="warning" tone="destructive" text={t({
        en: 'This could not be saved yet. Your draft is still here.', nl: 'Dit kon nog niet worden bewaard. Je concept staat er nog.',
      })} />}
    </View> : <>
      <View style={{ gap: spacing.xs }}>
        <TextBlock variant="title" selectable>{moment.title}</TextBlock>
        <TextBlock variant="meta" secondary>{meta}</TextBlock>
      </View>
      {sourceLine}
      {moment.body ? <TextBlock variant="rowTitle" selectable style={{ fontSize: 17, lineHeight: 26 }}>{moment.body}</TextBlock> : null}
    </>}

    {moment.questionSnapshot && !editing ? <>
      <Divider />
      <View style={{ gap: spacing.xs }}>
        <Eyebrow>{t({ en: 'The question', nl: 'De vraag' })}</Eyebrow>
        <TextBlock variant="voice">{moment.questionSnapshot}</TextBlock>
      </View>
      <Divider />
    </> : null}

    {audio && !editing ? <View style={[{ backgroundColor: palette.raised, borderRadius: radius.group, borderWidth: 1, borderColor: palette.divider, padding: spacing.group, gap: spacing.sm }, shadow(scheme)]}>
      <AudioPlayer uri={attachmentUri(audio)} durationMs={audio.durationMs} />
      <Divider style={{ marginTop: spacing.sm }} />
      <Pressable accessibilityRole="button" accessibilityLabel={t({ en: 'Delete this recording', nl: 'Verwijder deze opname' })} onPress={() => setSheet('deleteAudio')}
        style={({ pressed }) => ({ minHeight: geometry.touch, flexDirection: 'row', alignItems: 'center', gap: spacing.sm, opacity: pressed ? 0.6 : 1 })}>
        <Icon name="trash" color={palette.destructive} size={18} />
        <TextBlock variant="label" tone="destructive">{t({ en: 'Delete this recording', nl: 'Verwijder deze opname' })}</TextBlock>
      </Pressable>
    </View> : null}

    {!editing && <StatusLine icon="device" text={t({ en: `Saved on ${device.en}`, nl: `Bewaard op ${device.nl}` })} />}
    {notice ? <TextBlock variant="supporting" secondary accessibilityLiveRegion="polite">{notice}</TextBlock> : null}

    <Sheet visible={sheet === 'export'} onClose={() => setSheet(null)}>
      <View style={{ alignItems: 'center' }}><SheetBadge icon="share" /></View>
      <TextBlock variant="title" center>{t({ en: 'Export this moment', nl: 'Exporteer dit moment' })}</TextBlock>
      <TextBlock variant="body" secondary center>{t({
        en: 'Exports create a copy outside InnerUs. Choose what you want to share.',
        nl: 'Een export maakt een kopie buiten InnerUs. Kies wat je wilt delen.',
      })}</TextBlock>
      <Button icon="document" label={t({ en: 'Export the text', nl: 'Exporteer de tekst' })} onPress={() => void runExport('text')} />
      {audio && <Button variant="secondary" icon="mic" label={t({ en: 'Export the recording', nl: 'Exporteer de opname' })} onPress={() => void runExport('recording')} />}
      <Button variant="quiet" label={t({ en: 'Cancel', nl: 'Annuleren' })} onPress={() => setSheet(null)} />
    </Sheet>

    <Sheet visible={sheet === 'deleteMoment'} onClose={() => !busy && setSheet(null)}>
      <TextBlock variant="title">{t({ en: 'Delete this moment?', nl: 'Dit moment verwijderen?' })}</TextBlock>
      <TextBlock variant="body" secondary>{audio
        ? t({ en: `This removes the moment and its recording from InnerUs on ${device.en}. Copies you exported stay where you shared them.`, nl: `Dit verwijdert het moment en de opname uit InnerUs op ${device.nl}. Kopieën die je exporteerde, blijven waar je ze deelde.` })
        : t({ en: `This removes the moment from InnerUs on ${device.en}. Copies you exported stay where you shared them.`, nl: `Dit verwijdert het moment uit InnerUs op ${device.nl}. Kopieën die je exporteerde, blijven waar je ze deelde.` })}</TextBlock>
      <Button variant="destructiveFilled" icon="trash" label={t({ en: 'Delete this moment', nl: 'Verwijder dit moment' })} onPress={() => void confirmDeleteMoment()} loading={busy} />
      <Button variant="secondary" label={t({ en: 'Cancel', nl: 'Annuleren' })} onPress={() => setSheet(null)} disabled={busy} />
    </Sheet>

    <Sheet visible={sheet === 'deleteAudio'} onClose={() => !busy && setSheet(null)}>
      <TextBlock variant="title">{t({ en: 'Delete this recording?', nl: 'Deze opname verwijderen?' })}</TextBlock>
      <TextBlock variant="body" secondary>{t({
        en: 'The recording is removed from this moment. Your written note stays.',
        nl: 'De opname wordt uit dit moment verwijderd. Je geschreven notitie blijft.',
      })}</TextBlock>
      <Button variant="destructiveFilled" icon="trash" label={t({ en: 'Delete this recording', nl: 'Verwijder deze opname' })} onPress={() => void confirmDeleteAudio()} loading={busy} />
      <Button variant="secondary" label={t({ en: 'Cancel', nl: 'Annuleren' })} onPress={() => setSheet(null)} disabled={busy} />
    </Sheet>
  </Screen>;
}
