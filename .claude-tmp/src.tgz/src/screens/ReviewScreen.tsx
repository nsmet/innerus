import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Linking, Platform, TextInput, View } from 'react-native';
import { File } from 'expo-file-system';
import { getTopic } from '../content/catalogue';
import { SceneArt } from '../design/Art';
import { Icon } from '../design/Icon';
import {
  Button, Divider, Eyebrow, IconButton, ListGroup, ListRow, NoteField, Screen, Sheet, SheetBadge, StatusLine, TextBlock, ToggleRow,
} from '../design/primitives';
import { useDesign } from '../design/ThemeProvider';
import { geometry, radius, spacing, typography } from '../design/tokens';
import { AudioPlayer } from '../features/AudioPlayer';
import { getLocalProcessing, summarize, transcribe, type LocalProcessing } from '../features/localProcessing';
import type { StackProps } from '../navigation/types';
import { useAppStore } from '../state/AppStore';

type Phase = 'checking' | 'unavailable' | 'processing' | 'draft' | 'writing' | 'saved';

function deleteQuietly(uri: string) {
  try { const f = new File(uri); if (f.exists) f.delete(); } catch { /* best effort */ }
}

/**
 * UI08 review of one recorded clip (spec 23–29). Honest about local capability: in this build no
 * transcription adapter exists, so the person keeps the audio or writes the note. Never auto-saves.
 */
export function ReviewScreen({ route, navigation }: StackProps<'Review'>) {
  const { palette, t, language } = useDesign();
  const { prefs, saveMoment, attachAudio, deleteMoment } = useAppStore();
  const { uri, durationMs, source } = route.params;
  const topic = getTopic(source.topicId);
  const prompt = topic?.prompts.find(p => p.id === source.promptId);
  const question = prompt ? prompt.text[language] : null;
  const topicTitle = topic?.title[language] ?? '';
  const device = Platform.OS === 'ios' ? { en: 'this iPhone', nl: 'deze iPhone' } : { en: 'this device', nl: 'dit apparaat' };
  const deviceCaps = Platform.OS === 'ios' ? { en: 'On this iPhone', nl: 'Op deze iPhone' } : { en: 'On this device', nl: 'Op dit apparaat' };

  const [phase, setPhase] = useState<Phase>('checking');
  const [caps, setCaps] = useState<LocalProcessing | null>(null);
  const [progress, setProgress] = useState(0);
  const [problem, setProblem] = useState<'no-speech' | null>(null);
  // Writing / draft content
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [transcript, setTranscript] = useState('');
  const [editTranscript, setEditTranscript] = useState(false);
  const [editDraft, setEditDraft] = useState(false);
  // What to keep
  const [keepAudio, setKeepAudio] = useState(false);
  const [keepSummary, setKeepSummary] = useState(true);
  const [keepTranscript, setKeepTranscript] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(false);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [confirmDiscard, setConfirmDiscard] = useState(false);
  const leaving = useRef(false);
  const abort = useRef<AbortController | null>(null);

  const languageTag = prefs.recordingLanguage;
  const contentLanguage = languageTag.startsWith('nl') ? 'nl' as const : 'en' as const;

  const runProcessing = useCallback(async () => {
    setProblem(null);
    setProgress(0);
    setPhase('processing');
    const controller = new AbortController();
    abort.current = controller;
    const heard = await transcribe(uri, { languageTag, onProgress: setProgress, signal: controller.signal });
    if (controller.signal.aborted) return;
    if (!heard.ok) {
      if (heard.reason === 'no-speech') setProblem('no-speech');
      setPhase('unavailable');
      return;
    }
    setTranscript(heard.text);
    const draft = caps?.canSummarize
      ? await summarize({ transcript: heard.text, question, topicTitle }, { languageTag, signal: controller.signal })
      : { ok: false as const, reason: 'not-available' as const };
    if (controller.signal.aborted) return;
    if (draft.ok) {
      setTitle(draft.title);
      setBody(draft.paragraph);
      setKeepSummary(true); setKeepTranscript(false); setKeepAudio(false);
      setPhase('draft');
    } else {
      // Transcription ready, summary unavailable: edit or keep the transcript, or write manually.
      setTitle(topicTitle);
      setBody(heard.text);
      setPhase('writing');
    }
  }, [uri, languageTag, caps, question, topicTitle]);

  // Check what this device can do. Nothing is processed until the check says it is possible here.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const result = await getLocalProcessing(languageTag);
      if (cancelled) return;
      setCaps(result);
      setPhase('unavailable');
    })();
    return () => { cancelled = true; };
  }, [languageTag]);

  useEffect(() => {
    if (caps?.canTranscribe && phase === 'unavailable' && !problem && !transcript) void runProcessing();
    // Only once, right after the capability check.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [caps]);

  // Leaving with an unsaved clip always asks first (close button, Android back, gestures).
  useEffect(() => navigation.addListener('beforeRemove', event => {
    if (leaving.current || savedId) return;
    event.preventDefault();
    setConfirmDiscard(true);
  }), [navigation, savedId]);

  const leave = () => { leaving.current = true; navigation.goBack(); };

  const discard = () => {
    abort.current?.abort();
    deleteQuietly(uri);
    setConfirmDiscard(false);
    leave();
  };

  const base = () => ({
    topicId: source.topicId,
    topicVersion: topic?.version ?? '1',
    promptId: source.promptId,
    questionSnapshot: question,
    contentLanguage,
    participantLabel: null,
  });

  /** Saves a Moment and, when chosen, attaches the clip. Only reports success after both committed. */
  const commit = async (input: { title: string; body: string; source: 'typed' | 'reviewed-ai' | 'audio' }, withAudio: boolean) => {
    setSaving(true);
    setSaveError(false);
    let momentId: string | null = null;
    try {
      const saved = await saveMoment({ ...base(), ...input });
      momentId = saved.id;
      if (withAudio) await attachAudio(saved.id, uri, durationMs);
      else deleteQuietly(uri); // unselected temporary audio is removed after commit (spec 24)
      setSavedId(saved.id);
      setPhase('saved');
    } catch {
      // A voice-only Moment without its audio would be empty: roll it back so nothing half-saved remains.
      if (momentId && input.source === 'audio') { try { await deleteMoment(momentId); } catch { /* stays visible to the person */ } }
      setSaveError(true);
    } finally {
      setSaving(false);
    }
  };

  const voiceTitle = [t({ en: 'Voice note', nl: 'Spraaknotitie' }), topicTitle].filter(Boolean).join(' · ');

  const keepOriginalAudio = () => void commit({ title: voiceTitle, body: '', source: 'audio' }, true);

  const saveWritten = () => {
    const text = body.trim();
    const name = title.trim() || topicTitle || t({ en: 'A moment', nl: 'Een moment' });
    if (!text && keepAudio) { void commit({ title: name, body: '', source: 'audio' }, true); return; }
    void commit({ title: name, body: text, source: 'typed' }, keepAudio);
  };

  const saveDraft = () => {
    const name = title.trim() || topicTitle;
    if (keepSummary) {
      // There is no transcript attachment store yet: a kept transcript follows the summary in the note.
      const text = keepTranscript && transcript.trim()
        ? `${body.trim()}\n\n${t({ en: 'Full transcript', nl: 'Volledige tekst' })}:\n${transcript.trim()}`
        : body.trim();
      void commit({ title: name, body: text, source: 'reviewed-ai' }, keepAudio);
    } else if (keepTranscript) {
      void commit({ title: name, body: transcript.trim(), source: 'typed' }, keepAudio);
    } else if (keepAudio) {
      void commit({ title: voiceTitle, body: '', source: 'audio' }, true);
    }
  };

  const closeButton = <View style={{ marginTop: spacing.sm, marginLeft: -10, alignSelf: 'flex-start' }}>
    <IconButton name="close" label={t({ en: 'Close', nl: 'Sluiten' })} onPress={() => (phase === 'saved' ? leave() : setConfirmDiscard(true))} />
  </View>;

  const errorLine = saveError
    ? <StatusLine icon="warning" tone="destructive" text={t({ en: 'This could not be saved yet. Your draft is still here.', nl: 'Dit kon nog niet worden bewaard. Je concept staat er nog.' })} />
    : null;

  const titleInput = <TextInput value={title} onChangeText={setTitle} accessibilityLabel={t({ en: 'Title', nl: 'Titel' })}
    placeholder={t({ en: 'Title', nl: 'Titel' })} placeholderTextColor={palette.secondary}
    autoCorrect={false} spellCheck={false} autoComplete="off" importantForAutofill="no"
    style={[typography.heading, { color: palette.text, borderWidth: 1, borderColor: palette.outline, borderRadius: radius.control, paddingHorizontal: 14, paddingVertical: 10, minHeight: geometry.button }]} />;

  const onOff = { onLabel: t({ en: 'On', nl: 'Aan' }), offLabel: t({ en: 'Off', nl: 'Uit' }) };

  let content: React.ReactNode;
  let footer: React.ReactNode = null;

  if (phase === 'checking') {
    content = <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.group }}>
      <ActivityIndicator color={palette.text} />
      <TextBlock variant="body" secondary center accessibilityLiveRegion="polite">{t({
        en: `Checking what ${device.en} can do…`, nl: `Even nakijken wat ${device.nl} kan…`,
      })}</TextBlock>
    </View>;
  } else if (phase === 'processing') {
    content = <View style={{ flex: 1, justifyContent: 'center', gap: spacing.group }}>
      <Eyebrow>{t(deviceCaps)}</Eyebrow>
      <TextBlock variant="display">{t({ en: `Transcribing on ${device.en}`, nl: `Omzetten naar tekst op ${device.nl}` })}</TextBlock>
      <TextBlock variant="voice" secondary>{t({ en: 'Your audio stays here while it is turned into text.', nl: 'Je audio blijft hier terwijl ze naar tekst wordt omgezet.' })}</TextBlock>
      <View accessible accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 100, now: Math.round(progress * 100) }}
        style={{ height: 4, borderRadius: 2, backgroundColor: palette.divider, overflow: 'hidden' }}>
        <View style={{ width: `${Math.max(4, progress * 100)}%`, height: 4, backgroundColor: palette.text }} />
      </View>
      <TextBlock variant="supporting" secondary>{t({
        en: 'Model setup can use the internet. Your recording never does.',
        nl: 'Het installeren van een model kan internet gebruiken. Je opname nooit.',
      })}</TextBlock>
    </View>;
    footer = <>
      <Button variant="secondary" label={t({ en: 'Cancel', nl: 'Annuleren' })} onPress={() => { abort.current?.abort(); setPhase('unavailable'); }} />
      <Button variant="quiet" label={t({ en: 'Write it myself', nl: 'Zelf schrijven' })} onPress={() => { abort.current?.abort(); setTitle(topicTitle); setPhase('writing'); }} />
    </>;
  } else if (phase === 'unavailable') {
    content = <>
      <View style={{ marginTop: spacing.lg }}><SceneArt family="notebook" height={200} /></View>
      <TextBlock variant="title">{problem === 'no-speech'
        ? t({ en: 'No useful speech was recognized.', nl: 'Er is geen bruikbare spraak herkend.' })
        : t({ en: `A local summary is not available on ${device.en} right now.`, nl: `Een lokale samenvatting is nu niet beschikbaar op ${device.nl}.` })}</TextBlock>
      <TextBlock variant="body" secondary>{problem === 'no-speech'
        ? t({ en: 'Replay, retry or write a note.', nl: 'Luister opnieuw, probeer nog eens of schrijf een notitie.' })
        : t({ en: 'You can still keep a note or recording.', nl: 'Je kunt wel een notitie of opname bewaren.' })}</TextBlock>
      <StatusLine icon="device" text={t({ en: `Your recording stays on ${device.en}`, nl: `Je opname blijft op ${device.nl}` })} />
      {errorLine}
    </>;
    footer = <>
      <Button icon="pen" label={t({ en: 'Write it myself', nl: 'Zelf schrijven' })} onPress={() => { setTitle(topicTitle); setSaveError(false); setPhase('writing'); }} disabled={saving} />
      <Button variant="secondary" label={t({ en: 'Keep the original audio', nl: 'Bewaar de originele audio' })} onPress={keepOriginalAudio} loading={saving} />
      {problem === 'no-speech' && caps?.canTranscribe && <Button variant="quiet" icon="refresh" label={t({ en: 'Try again', nl: 'Opnieuw proberen' })} onPress={() => void runProcessing()} />}
      {caps?.transcription === 'needs-download' && <View style={{ gap: spacing.xs }}>
        <Button variant="quiet" icon="download" label={t({ en: 'Download language support', nl: 'Download taalondersteuning' })} onPress={() => void Linking.openSettings()} />
        <TextBlock variant="supporting" secondary center>{t({
          en: 'Opens the system settings, where you can add this language. Your recording stays here.',
          nl: 'Opent de systeeminstellingen, waar je deze taal kunt toevoegen. Je opname blijft hier.',
        })}</TextBlock>
      </View>}
    </>;
  } else if (phase === 'writing') {
    content = <>
      {topicTitle ? <Eyebrow>{topicTitle}</Eyebrow> : null}
      <TextBlock variant="title">{t({ en: 'In your own words', nl: 'In je eigen woorden' })}</TextBlock>
      {question ? <TextBlock variant="voice" secondary>{question}</TextBlock> : null}
      <View style={{ backgroundColor: palette.warm, borderRadius: radius.group, padding: spacing.group }}>
        <AudioPlayer uri={uri} durationMs={durationMs} title={t({ en: 'Your recording', nl: 'Je opname' })} />
      </View>
      {titleInput}
      <NoteField value={body} onChangeText={setBody} label={t({ en: 'Your note', nl: 'Je notitie' })} autoFocus={!body}
        placeholder={t({ en: 'A detail, a thought, a small idea...', nl: 'Een detail, een gedachte, een klein idee...' })} minHeight={160} />
      <ListGroup>
        <ToggleRow icon="mic" title={t({ en: 'Keep the original audio', nl: 'Bewaar de originele audio' })} value={keepAudio} onChange={setKeepAudio} {...onOff} />
      </ListGroup>
      {errorLine}
    </>;
    footer = <>
      <Button label={t({ en: 'Save this moment', nl: 'Bewaar dit moment' })} onPress={saveWritten} loading={saving}
        disabled={!body.trim() && !keepAudio} reason={t({ en: 'Write a few words, or keep the original audio.', nl: 'Schrijf een paar woorden, of bewaar de originele audio.' })} />
      <Button variant="quiet" icon="trash" label={t({ en: 'Discard', nl: 'Verwijderen' })} onPress={() => setConfirmDiscard(true)} disabled={saving} />
    </>;
  } else if (phase === 'draft') {
    content = <>
      <View style={{ flexDirection: 'row' }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: palette.warm, borderWidth: 1, borderColor: palette.divider, borderRadius: radius.control, paddingHorizontal: 10, paddingVertical: 6 }}>
          <Icon name="document" color={palette.text} size={14} />
          <TextBlock variant="supporting" style={{ fontWeight: '600' }}>{t({ en: 'Draft memory', nl: 'Voorstel voor een herinnering' })}</TextBlock>
        </View>
      </View>
      {editDraft ? <>
        {titleInput}
        <NoteField value={body} onChangeText={setBody} label={t({ en: 'Draft memory', nl: 'Voorstel voor een herinnering' })} placeholder="" minHeight={160} />
      </> : <>
        <TextBlock variant="title">{title}</TextBlock>
        <TextBlock variant="rowTitle" style={{ fontSize: 17, lineHeight: 26 }}>{body}</TextBlock>
        <Button variant="quiet" icon="pen" label={t({ en: 'Edit', nl: 'Bewerken' })} onPress={() => setEditDraft(true)} />
      </>}
      <TextBlock variant="supporting" secondary>{t({ en: 'Check that this says what you meant before saving.', nl: 'Controleer voor het bewaren of dit weergeeft wat je bedoelde.' })}</TextBlock>
      <Divider />
      <ListRow title={t({ en: 'Edit the transcript', nl: 'Bewerk de tekst' })} onPress={() => setEditTranscript(v => !v)} chevron />
      {editTranscript && <NoteField value={transcript} onChangeText={setTranscript} label={t({ en: 'Transcript', nl: 'Tekst' })} placeholder="" minHeight={160} />}
      <ListGroup title={t({ en: 'What to keep', nl: 'Wat je bewaart' })}>
        <ToggleRow title={t({ en: 'Short memory', nl: 'Korte herinnering' })} detail={t({ en: 'Title and paragraph', nl: 'Titel en alinea' })} value={keepSummary} onChange={setKeepSummary} {...onOff} />
        <ToggleRow title={t({ en: 'Keep the full transcript', nl: 'Bewaar de volledige tekst' })} value={keepTranscript} onChange={setKeepTranscript} {...onOff} />
        <ToggleRow title={t({ en: 'Keep the original audio', nl: 'Bewaar de originele audio' })} value={keepAudio} onChange={setKeepAudio} {...onOff} />
      </ListGroup>
      {errorLine}
    </>;
    footer = <>
      <Button label={t({ en: 'Save selected items', nl: 'Bewaar de gekozen onderdelen' })} onPress={saveDraft} loading={saving}
        disabled={!keepSummary && !keepTranscript && !keepAudio} reason={t({ en: 'Choose at least one item to keep.', nl: 'Kies minstens één onderdeel om te bewaren.' })} />
      <View style={{ flexDirection: 'row', justifyContent: 'center', gap: spacing.lg }}>
        <Button variant="quiet" icon="refresh" label={t({ en: 'Try again', nl: 'Opnieuw proberen' })} onPress={() => void runProcessing()} disabled={saving} />
        <Button variant="quiet" icon="trash" label={t({ en: 'Discard', nl: 'Verwijderen' })} onPress={() => setConfirmDiscard(true)} disabled={saving} />
      </View>
    </>;
  } else {
    content = <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', gap: spacing.group }}>
      <SheetBadge icon="check" />
      <TextBlock variant="title" center>{t({ en: 'A little piece of us.', nl: 'Een klein stukje van ons.' })}</TextBlock>
      <StatusLine icon="device" text={t({ en: `Saved on ${device.en}`, nl: `Bewaard op ${device.nl}` })} />
    </View>;
    footer = <>
      <Button label={source.sessionId ? t({ en: 'Back to the conversation', nl: 'Terug naar het gesprek' }) : t({ en: 'Done', nl: 'Klaar' })} onPress={leave} />
      {savedId && <Button variant="quiet" label={t({ en: 'Open this moment', nl: 'Open dit moment' })}
        onPress={() => { leaving.current = true; navigation.replace('MomentDetail', { momentId: savedId }); }} />}
    </>;
  }

  return <Screen header={closeButton} footer={footer} edges={['top', 'bottom']}>
    {content}
    <Sheet visible={confirmDiscard} onClose={() => setConfirmDiscard(false)}>
      <TextBlock variant="title">{t({ en: 'Discard this recording?', nl: 'Deze opname verwijderen?' })}</TextBlock>
      <TextBlock variant="body" secondary>{t({
        en: `The clip and anything you wrote here are removed from ${device.en}. Moments you already saved are not affected.`,
        nl: `De opname en wat je hier schreef, worden van ${device.nl} verwijderd. Momenten die je al bewaarde, blijven staan.`,
      })}</TextBlock>
      <Button variant="destructiveFilled" icon="trash" label={t({ en: 'Discard recording', nl: 'Verwijder de opname' })} onPress={discard} />
      <Button variant="secondary" label={t({ en: 'Stay here', nl: 'Blijf hier' })} onPress={() => setConfirmDiscard(false)} />
    </Sheet>
  </Screen>;
}
