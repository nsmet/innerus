import { useEffect, useRef } from 'react';
import { useAppStore } from '../state/AppStore';
import { checkCollectionOwnership, collectionPurchasedThisSession, setCollectionOwnedHandler } from './store';

/**
 * Quietly resolves the collection entitlement from the platform store once per app start (spec 11/38).
 * Never blocks the UI and never derives ownership from a stored or synced flag (spec 35).
 * Also listens for purchases that complete later (pending / Ask to Buy approvals).
 */
export function useEntitlementBootstrap() {
  const { setEntitlement } = useAppStore();
  const started = useRef(false);

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    setCollectionOwnedHandler(() => setEntitlement({ owned: true, checked: true }));
    void checkCollectionOwnership()
      .then(result => setEntitlement({ owned: result === 'owned' || collectionPurchasedThisSession(), checked: true }))
      .catch(() => setEntitlement({ owned: collectionPurchasedThisSession(), checked: true }));
  }, [setEntitlement]);
}
