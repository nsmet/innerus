import { Platform } from 'react-native';
import {
  ErrorCode, endConnection, fetchProducts, finishTransaction, getAvailablePurchases, initConnection,
  purchaseErrorListener, purchaseUpdatedListener, requestPurchase, restorePurchases,
  type Purchase,
} from 'expo-iap';

/**
 * Direct platform store adapter (StoreKit 2 / Google Play Billing via expo-iap). No InnerUs server,
 * no third-party customer service, no entitlement from synced flags (handoff §35/§38, D19).
 * Ownership is only ever derived from the store's own purchase records for the collection product.
 * Errors are swallowed into typed results; nothing is logged.
 */

/** Development placeholder. NOT a production product ID; the live IDs are a release gate (legacy audit). */
export const DEVELOPMENT_COLLECTION_PRODUCT_ID = 'local.innerus.development.collection';
export const COLLECTION_PRODUCT_ID = DEVELOPMENT_COLLECTION_PRODUCT_ID;

export type StoreProbe = {
  state: 'connected' | 'unavailable';
  productsFound: number;
  detail: string;
};

/** Connects, asks the store for the development product, disconnects. Never purchases. (Dev probe screen only.) */
export async function probeStore(): Promise<StoreProbe> {
  try {
    const connected = await initConnection();
    if (!connected) return { state: 'unavailable', productsFound: 0, detail: 'initConnection returned false' };
    const products = (await fetchProducts({ skus: [DEVELOPMENT_COLLECTION_PRODUCT_ID], type: 'in-app' })) ?? [];
    return { state: 'connected', productsFound: products.length, detail: products.length ? 'product metadata returned by the store' : 'connected; development product not configured in the store (expected)' };
  } catch (error) {
    return { state: 'unavailable', productsFound: 0, detail: error instanceof Error ? error.message.slice(0, 160) : 'store error' };
  } finally {
    try { await endConnection(); } catch { /* ignore */ }
    connection = null;
  }
}

// ---------------------------------------------------------------------------------------------
// Connection and the single purchase observer
// ---------------------------------------------------------------------------------------------
let connection: Promise<boolean> | null = null;

/** One shared store connection for the app's lifetime. Resolves false when the store is unavailable. */
async function connect(): Promise<boolean> {
  if (!connection) {
    connection = initConnection().then(ok => !!ok).catch(() => false);
  }
  const ok = await connection;
  if (!ok) connection = null; // allow a later retry
  else ensureListeners();
  return ok;
}

export type PurchaseOutcome = 'purchased' | 'pending' | 'cancelled' | 'failed' | 'owned' | 'unavailable';

let listening = false;
let waiter: ((outcome: PurchaseOutcome) => void) | null = null;
let ownedHandler: (() => void) | null = null;
let ownedThisSession = false;

function settle(outcome: PurchaseOutcome) {
  const resolve = waiter;
  waiter = null;
  resolve?.(outcome);
}

function ensureListeners() {
  if (listening) return;
  listening = true;
  purchaseUpdatedListener(purchase => { void handlePurchase(purchase); });
  purchaseErrorListener(error => { settle(outcomeForError(error)); });
}

async function handlePurchase(purchase: Purchase) {
  if (purchase.productId !== COLLECTION_PRODUCT_ID) return;
  if (purchase.purchaseState === 'pending') { settle('pending'); return; }
  if (purchase.purchaseState !== 'purchased') return;
  // Non-consumable: finishing acknowledges on Android and clears the StoreKit queue on iOS.
  try { await finishTransaction({ purchase, isConsumable: false }); } catch { /* replays next launch */ }
  ownedThisSession = true;
  ownedHandler?.();
  settle('purchased');
}

function outcomeForError(error: { code?: unknown } | null | undefined): PurchaseOutcome {
  switch (error?.code) {
    case ErrorCode.UserCancelled: return 'cancelled';
    case ErrorCode.Pending:
    case ErrorCode.DeferredPayment: return 'pending';
    case ErrorCode.AlreadyOwned: return 'owned';
    case ErrorCode.ItemUnavailable:
    case ErrorCode.IapNotAvailable:
    case ErrorCode.BillingUnavailable: return 'unavailable';
    default: return 'failed';
  }
}

/** Called whenever a store purchase of the collection completes (also late, e.g. after "Ask to Buy"). */
export function setCollectionOwnedHandler(handler: (() => void) | null) {
  ownedHandler = handler;
  void connect();
}

/** True once a store purchase completed in this app session (guards a slower ownership check). */
export function collectionPurchasedThisSession() {
  return ownedThisSession;
}

// ---------------------------------------------------------------------------------------------
// Product, ownership, purchase, restore
// ---------------------------------------------------------------------------------------------
export type CollectionProduct =
  | { status: 'ready'; displayPrice: string; title: string; description: string }
  | { status: 'unavailable' };

/** The store's localized price for the collection. Unavailable in development (product not configured). */
export async function fetchCollectionProduct(): Promise<CollectionProduct> {
  try {
    if (!(await connect())) return { status: 'unavailable' };
    const products = (await fetchProducts({ skus: [COLLECTION_PRODUCT_ID], type: 'in-app' })) ?? [];
    const product = products.find(p => p.id === COLLECTION_PRODUCT_ID);
    if (!product || !product.displayPrice) return { status: 'unavailable' };
    return { status: 'ready', displayPrice: product.displayPrice, title: product.title, description: product.description };
  } catch {
    return { status: 'unavailable' };
  }
}

export type OwnershipCheck = 'owned' | 'not-owned' | 'error';

/** Asks the store which non-consumables this store account holds. */
export async function checkCollectionOwnership(): Promise<OwnershipCheck> {
  try {
    if (!(await connect())) return 'error';
    const purchases = (await getAvailablePurchases()) ?? [];
    const match = purchases.find(p => p.productId === COLLECTION_PRODUCT_ID && p.purchaseState === 'purchased');
    if (!match) return 'not-owned';
    if (Platform.OS === 'android' && 'isAcknowledgedAndroid' in match && match.isAcknowledgedAndroid === false) {
      try { await finishTransaction({ purchase: match, isConsumable: false }); } catch { /* retried next launch */ }
    }
    return 'owned';
  } catch {
    return 'error';
  }
}

/**
 * Starts the platform purchase sheet. Resolves with the first store outcome for the collection.
 * Never grants anything itself; a `purchased` outcome means the store reported a completed purchase.
 */
export async function purchaseCollection(): Promise<PurchaseOutcome> {
  if (!(await connect())) return 'unavailable';
  settle('cancelled'); // a previous unanswered request is superseded
  const result = new Promise<PurchaseOutcome>(resolve => { waiter = resolve; });
  try {
    await requestPurchase({
      type: 'in-app',
      request: {
        apple: { sku: COLLECTION_PRODUCT_ID },
        google: { skus: [COLLECTION_PRODUCT_ID] },
      },
    });
  } catch (error) {
    settle(outcomeForError(error as { code?: unknown } | null));
  }
  return result;
}

export type RestoreOutcome = 'restored' | 'nothing' | 'error';

/** Explicit Restore Purchases: syncs with the store, then reads ownership from it. */
export async function restoreCollection(): Promise<RestoreOutcome> {
  try {
    if (!(await connect())) return 'error';
    try { await restorePurchases(); } catch { /* fall through to the ownership read */ }
    const check = await checkCollectionOwnership();
    return check === 'owned' ? 'restored' : check === 'not-owned' ? 'nothing' : 'error';
  } catch {
    return 'error';
  }
}
