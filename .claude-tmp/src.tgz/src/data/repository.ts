import type { Language } from '../content/types';
import type { SqlDatabase } from './sql';

/**
 * Private local repository. Every write commits before the caller may show "Saved on this device"
 * (spec 20/32). Errors carry no personal content. No method talks to a network.
 */
export type MomentSource = 'typed' | 'reviewed-ai' | 'audio';
export type Moment = {
  id: string;
  topicId: string;
  topicVersion: string;
  promptId: string | null;
  questionSnapshot: string | null;
  contentLanguage: Language;
  title: string;
  body: string;
  source: MomentSource;
  participantLabel: string | null;
  version: number;
  createdAt: string;
  updatedAt: string;
};
export type NewMoment = Omit<Moment, 'version' | 'createdAt' | 'updatedAt'>;

export type ActiveSession = {
  sessionId: string;
  topicId: string;
  topicVersion: string;
  /** 0..4 = authored prompt index, 5 = closing invitation. */
  position: number;
  nudgeShown: boolean;
  language: Language;
  startedAt: string;
  updatedAt: string;
};
export const CLOSING_POSITION = 5;

export type Attachment = { id: string; momentId: string; kind: 'audio' | 'transcript'; relativePath: string; bytes: number; durationMs: number | null; createdAt: string };

export type Draft = { sessionId: string; promptId: string | null; title: string; body: string; updatedAt: string };

type MomentRow = {
  id: string; topic_id: string; topic_version: string; prompt_id: string | null; question_snapshot: string | null;
  content_language: Language; title: string; body: string; source: MomentSource; participant_label: string | null;
  version: number; created_at: string; updated_at: string;
};
const toMoment = (r: MomentRow): Moment => ({
  id: r.id, topicId: r.topic_id, topicVersion: r.topic_version, promptId: r.prompt_id, questionSnapshot: r.question_snapshot,
  contentLanguage: r.content_language, title: r.title, body: r.body, source: r.source, participantLabel: r.participant_label,
  version: r.version, createdAt: r.created_at, updatedAt: r.updated_at,
});

export class PrivateRepository {
  constructor(private readonly db: SqlDatabase, private readonly now: () => string = () => new Date().toISOString()) {}

  /**
   * All writes run one at a time on the single connection. expo-sqlite transactions are not
   * exclusive, so overlapping writes (e.g. two quick Finish taps) would otherwise interleave.
   */
  private queue: Promise<unknown> = Promise.resolve();
  private serial<T>(task: () => Promise<T>): Promise<T> {
    const result = this.queue.then(task, task);
    this.queue = result.catch(() => undefined);
    return result;
  }

  // ---- Moments ------------------------------------------------------------------------------

  /**
   * Idempotent: saving the same Moment id twice (double tap, retry after a crash) keeps one row
   * and returns the stored version. A tombstoned id is never recreated.
   */
  saveMoment(input: NewMoment): Promise<Moment> {
    return this.serial(async () => {
      if (await this.isTombstoned('moment', input.id)) throw new Error('This moment was deleted.');
      const at = this.now();
      await this.db.runAsync(
        `INSERT OR IGNORE INTO moments (id, topic_id, topic_version, prompt_id, question_snapshot, content_language, title, body, source, participant_label, version, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`,
        [input.id, input.topicId, input.topicVersion, input.promptId, input.questionSnapshot, input.contentLanguage,
          input.title, input.body, input.source, input.participantLabel, at, at],
      );
      const saved = await this.getMoment(input.id);
      if (!saved) throw new Error('The moment could not be saved.');
      return saved;
    });
  }

  async getMoment(id: string): Promise<Moment | null> {
    const row = await this.db.getFirstAsync<MomentRow>('SELECT * FROM moments WHERE id = ?', [id]);
    return row ? toMoment(row) : null;
  }

  /** Newest first, optional topic filter (spec 21). */
  async listMoments(topicId?: string): Promise<Moment[]> {
    const rows = topicId
      ? await this.db.getAllAsync<MomentRow>('SELECT * FROM moments WHERE topic_id = ? ORDER BY created_at DESC, rowid DESC', [topicId])
      : await this.db.getAllAsync<MomentRow>('SELECT * FROM moments ORDER BY created_at DESC, rowid DESC');
    return rows.map(toMoment);
  }

  /**
   * Edits keep the previous text as a recoverable version (spec 21/34). `expectedVersion` rejects
   * stale edits instead of silently overwriting someone's words.
   */
  updateMoment(id: string, expectedVersion: number, changes: { title?: string; body?: string; participantLabel?: string | null }): Promise<Moment> {
    return this.serial(async () => {
      let updated: Moment | null = null;
      await this.db.withTransactionAsync(async () => {
        const current = await this.getMoment(id);
        if (!current) throw new Error('This moment no longer exists.');
        if (current.version !== expectedVersion) throw new Error('This moment changed elsewhere. Review the other version.');
        await this.db.runAsync('INSERT OR IGNORE INTO moment_versions (moment_id, version, title, body, saved_at) VALUES (?, ?, ?, ?, ?)',
          [id, current.version, current.title, current.body, current.updatedAt]);
        await this.db.runAsync(
          'UPDATE moments SET title = ?, body = ?, participant_label = ?, version = version + 1, updated_at = ? WHERE id = ? AND version = ?',
          [changes.title ?? current.title, changes.body ?? current.body,
            changes.participantLabel === undefined ? current.participantLabel : changes.participantLabel, this.now(), id, expectedVersion],
        );
        updated = await this.getMoment(id);
      });
      if (!updated) throw new Error('This moment could not be updated.');
      return updated;
    });
  }

  /** Deletes the Moment, its versions and attachment rows, and records a non-content tombstone. */
  deleteMoment(id: string): Promise<void> {
    return this.serial(async () => {
      await this.db.withTransactionAsync(async () => {
        await this.db.runAsync('DELETE FROM moment_versions WHERE moment_id = ?', [id]);
        await this.db.runAsync('DELETE FROM moments WHERE id = ?', [id]);
        await this.db.runAsync('INSERT OR REPLACE INTO tombstones (entity, id, deleted_at) VALUES (?, ?, ?)', ['moment', id, this.now()]);
      });
    });
  }

  async isTombstoned(entity: string, id: string): Promise<boolean> {
    return (await this.db.getFirstAsync('SELECT 1 AS hit FROM tombstones WHERE entity = ? AND id = ?', [entity, id])) != null;
  }

  /** Entirely local full-text search; diacritics-insensitive (café = cafe). Query text is never stored. */
  async searchMoments(query: string): Promise<Moment[]> {
    const terms = query.normalize('NFC').split(/\s+/).map(t => t.replace(/["*^():]/g, '')).filter(Boolean);
    if (!terms.length) return this.listMoments();
    const match = terms.map(t => `"${t}"*`).join(' ');
    const rows = await this.db.getAllAsync<MomentRow>(
      `SELECT m.* FROM moments_search s JOIN moments m ON m.rowid = s.rowid WHERE moments_search MATCH ? ORDER BY m.created_at DESC`,
      [match],
    );
    return rows.map(toMoment);
  }

  // ---- Session, drafts, completion -----------------------------------------------------------

  async getActiveSession(): Promise<ActiveSession | null> {
    const r = await this.db.getFirstAsync<{ session_id: string; topic_id: string; topic_version: string; position: number; nudge_shown: number; language: Language; started_at: string; updated_at: string }>(
      'SELECT * FROM active_session WHERE slot = 1');
    return r ? { sessionId: r.session_id, topicId: r.topic_id, topicVersion: r.topic_version, position: r.position, nudgeShown: r.nudge_shown === 1, language: r.language, startedAt: r.started_at, updatedAt: r.updated_at } : null;
  }

  /** Saves the one resumable position (spec 20). Replaces any previous session. */
  saveActiveSession(session: Omit<ActiveSession, 'updatedAt'>): Promise<void> {
    return this.serial(async () => {
      if (session.position < 0 || session.position > CLOSING_POSITION) throw new Error('Invalid conversation position.');
      await this.db.runAsync(
        `INSERT OR REPLACE INTO active_session (slot, session_id, topic_id, topic_version, position, nudge_shown, language, started_at, updated_at)
         VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [session.sessionId, session.topicId, session.topicVersion, session.position, session.nudgeShown ? 1 : 0, session.language, session.startedAt, this.now()],
      );
    });
  }

  clearActiveSession(): Promise<void> {
    return this.serial(async () => {
      await this.db.runAsync('DELETE FROM active_session WHERE slot = 1');
    });
  }

  saveDraft(draft: Omit<Draft, 'updatedAt'>): Promise<void> {
    return this.serial(async () => {
      await this.db.runAsync('INSERT OR REPLACE INTO drafts (session_id, prompt_id, title, body, updated_at) VALUES (?, ?, ?, ?, ?)',
        [draft.sessionId, draft.promptId, draft.title, draft.body, this.now()]);
    });
  }

  async getDraft(sessionId: string): Promise<Draft | null> {
    const r = await this.db.getFirstAsync<{ session_id: string; prompt_id: string | null; title: string; body: string; updated_at: string }>(
      'SELECT * FROM drafts WHERE session_id = ?', [sessionId]);
    return r ? { sessionId: r.session_id, promptId: r.prompt_id, title: r.title, body: r.body, updatedAt: r.updated_at } : null;
  }

  discardDraft(sessionId: string): Promise<void> {
    return this.serial(async () => {
      await this.db.runAsync('DELETE FROM drafts WHERE session_id = ?', [sessionId]);
    });
  }

  /**
   * Explicit Finish. Records at most one completion per session identity (AC43) and clears the
   * resumable position in the same transaction. Returns false when already recorded.
   */
  recordCompletion(sessionId: string, topicId: string): Promise<boolean> {
    return this.serial(async () => {
      let inserted = false;
      await this.db.withTransactionAsync(async () => {
        const result = await this.db.runAsync('INSERT OR IGNORE INTO completions (session_id, topic_id, completed_at) VALUES (?, ?, ?)', [sessionId, topicId, this.now()]);
        inserted = result.changes === 1;
        await this.db.runAsync('DELETE FROM active_session WHERE slot = 1 AND session_id = ?', [sessionId]);
      });
      return inserted;
    });
  }

  async completionCount(topicId?: string): Promise<number> {
    const r = topicId
      ? await this.db.getFirstAsync<{ n: number }>('SELECT COUNT(*) AS n FROM completions WHERE topic_id = ?', [topicId])
      : await this.db.getFirstAsync<{ n: number }>('SELECT COUNT(*) AS n FROM completions');
    return r?.n ?? 0;
  }

  // ---- Attachments (retained voice clips / transcripts) -----------------------------------------

  async addAttachment(attachment: Omit<Attachment, 'createdAt'>): Promise<void> {
    return this.serial(async () => {
      await this.db.runAsync('INSERT OR IGNORE INTO attachments (id, moment_id, kind, relative_path, bytes, duration_ms, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [attachment.id, attachment.momentId, attachment.kind, attachment.relativePath, attachment.bytes, attachment.durationMs, this.now()]);
    });
  }

  async listAttachments(momentId?: string): Promise<Attachment[]> {
    type Row = { id: string; moment_id: string; kind: 'audio' | 'transcript'; relative_path: string; bytes: number; duration_ms: number | null; created_at: string };
    const rows = momentId
      ? await this.db.getAllAsync<Row>('SELECT * FROM attachments WHERE moment_id = ? ORDER BY created_at', [momentId])
      : await this.db.getAllAsync<Row>('SELECT * FROM attachments ORDER BY created_at');
    return rows.map(r => ({ id: r.id, momentId: r.moment_id, kind: r.kind, relativePath: r.relative_path, bytes: r.bytes, durationMs: r.duration_ms, createdAt: r.created_at }));
  }

  /** Removes the attachment row; the caller deletes the file. The written note stays (spec 33/37). */
  async deleteAttachment(id: string): Promise<void> {
    return this.serial(async () => {
      await this.db.runAsync('DELETE FROM attachments WHERE id = ?', [id]);
      await this.db.runAsync('INSERT OR REPLACE INTO tombstones (entity, id, deleted_at) VALUES (?, ?, ?)', ['attachment', id, this.now()]);
    });
  }

  // ---- Preferences (device-specific) ----------------------------------------------------------

  async getPreferences(): Promise<Record<string, string>> {
    const rows = await this.db.getAllAsync<{ key: string; value: string }>('SELECT key, value FROM preferences');
    return Object.fromEntries(rows.map(r => [r.key, r.value]));
  }

  async setPreference(key: string, value: string | null): Promise<void> {
    return this.serial(async () => {
      if (value === null) await this.db.runAsync('DELETE FROM preferences WHERE key = ?', [key]);
      else await this.db.runAsync('INSERT OR REPLACE INTO preferences (key, value) VALUES (?, ?)', [key, value]);
    });
  }

  /**
   * "Delete all private app content" (spec 37): Moments, versions, attachments rows, bookmarks,
   * preferences, drafts and the active session. Keeps non-content tombstones and completion counts
   * are removed too. Purchase entitlement is store-derived and unaffected. The caller removes files.
   */
  async deleteAllPrivateContent(): Promise<void> {
    return this.serial(async () => {
      await this.db.withTransactionAsync(async () => {
        const ids = await this.db.getAllAsync<{ id: string }>('SELECT id FROM moments');
        for (const { id } of ids) await this.db.runAsync('INSERT OR REPLACE INTO tombstones (entity, id, deleted_at) VALUES (?, ?, ?)', ['moment', id, this.now()]);
        for (const table of ['attachments', 'moment_versions', 'moments', 'bookmarks', 'preferences', 'drafts', 'active_session', 'completions']) {
          await this.db.runAsync(`DELETE FROM ${table}`);
        }
      });
    });
  }

  // ---- Bookmarks ------------------------------------------------------------------------------

  setBookmark(topicId: string, bookmarked: boolean): Promise<void> {
    return this.serial(async () => {
      if (bookmarked) await this.db.runAsync('INSERT OR IGNORE INTO bookmarks (topic_id, created_at) VALUES (?, ?)', [topicId, this.now()]);
      else await this.db.runAsync('DELETE FROM bookmarks WHERE topic_id = ?', [topicId]);
    });
  }

  async listBookmarks(): Promise<string[]> {
    return (await this.db.getAllAsync<{ topic_id: string }>('SELECT topic_id FROM bookmarks ORDER BY created_at DESC')).map(r => r.topic_id);
  }
}
