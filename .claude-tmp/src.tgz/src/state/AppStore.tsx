import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { getLocales } from 'expo-localization';
import { uuid } from 'expo';
import { Directory, File } from 'expo-file-system';
import { openPrivateStore } from '../data/openPrivateStore';
import type { ActiveSession, Attachment, Moment, NewMoment, PrivateRepository } from '../data/repository';
import type { Language } from '../content/types';

/**
 * App state for InnerUs. Everything personal lives in the protected private store (src/data).
 * Components never import this for storage side effects; screens do (handoff §53).
 */
export type AppearancePref = 'system' | 'light' | 'dark';
export type LanguagePref = 'system' | Language;
export type Prefs = {
  language: LanguagePref;
  appearance: AppearancePref;
  recordingLanguage: 'en-US' | 'nl-NL' | 'nl-BE';
  appLock: boolean;
  reminders: { enabled: boolean; weekday: number; hour: number; minute: number };
  privacyNoteDismissed: boolean;
  quickHistory: string[];
  resumeDismissedSession: string | null;
  hiddenThemes: string[];
};

const defaultPrefs: Prefs = {
  language: 'system',
  appearance: 'system',
  recordingLanguage: 'nl-BE',
  appLock: false,
  reminders: { enabled: false, weekday: 5, hour: 20, minute: 30 },
  privacyNoteDismissed: false,
  quickHistory: [],
  resumeDismissedSession: null,
  hiddenThemes: [],
};

export type Entitlement = { owned: boolean; checked: boolean };

type Store = {
  ready: boolean;
  storageError: string | null;
  repository: PrivateRepository | null;
  privateDirectory: string | null;
  prefs: Prefs;
  language: Language;
  setPref: <K extends keyof Prefs>(key: K, value: Prefs[K]) => Promise<void>;
  moments: Moment[];
  attachments: Attachment[];
  bookmarks: string[];
  completions: Record<string, number>;
  activeSession: ActiveSession | null;
  entitlement: Entitlement;
  setEntitlement: (value: Entitlement) => void;
  refresh: () => Promise<void>;
  // Conversation
  startSession: (topicId: string, topicVersion: string) => Promise<ActiveSession>;
  saveSession: (session: ActiveSession) => Promise<void>;
  finishSession: (sessionId: string, topicId: string) => Promise<void>;
  dismissResume: () => Promise<void>;
  // Moments
  saveMoment: (input: Omit<NewMoment, 'id'> & { id?: string }) => Promise<Moment>;
  updateMoment: (id: string, expectedVersion: number, changes: { title?: string; body?: string }) => Promise<Moment>;
  deleteMoment: (id: string) => Promise<void>;
  attachAudio: (momentId: string, sourceUri: string, durationMs: number) => Promise<void>;
  removeAttachment: (attachment: Attachment) => Promise<void>;
  attachmentUri: (attachment: Attachment) => string;
  toggleBookmark: (topicId: string) => Promise<void>;
  deleteAllPrivateContent: () => Promise<void>;
};

const Context = createContext<Store | null>(null);

function deviceLanguage(): Language {
  return getLocales()[0]?.languageCode === 'nl' ? 'nl' : 'en';
}

function parsePrefs(raw: Record<string, string>): Prefs {
  const prefs = { ...defaultPrefs };
  for (const key of Object.keys(defaultPrefs) as (keyof Prefs)[]) {
    if (raw[key] === undefined) continue;
    try { (prefs as Record<string, unknown>)[key] = JSON.parse(raw[key]); } catch { /* keep default */ }
  }
  return prefs;
}

export function AppStoreProvider({ children }: React.PropsWithChildren) {
  const [ready, setReady] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);
  const [repository, setRepository] = useState<PrivateRepository | null>(null);
  const [privateDirectory, setPrivateDirectory] = useState<string | null>(null);
  const [prefs, setPrefs] = useState<Prefs>(defaultPrefs);
  const [moments, setMoments] = useState<Moment[]>([]);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [completions, setCompletions] = useState<Record<string, number>>({});
  const [activeSession, setActiveSession] = useState<ActiveSession | null>(null);
  const [entitlement, setEntitlement] = useState<Entitlement>({ owned: false, checked: false });
  const repoRef = useRef<PrivateRepository | null>(null);

  const load = useCallback(async (repo: PrivateRepository) => {
    const [m, a, b, s, p] = await Promise.all([repo.listMoments(), repo.listAttachments(), repo.listBookmarks(), repo.getActiveSession(), repo.getPreferences()]);
    const counts: Record<string, number> = {};
    for (const id of ['A01', 'A02', 'A03', 'A04', 'A05', 'B01', 'B02', 'B03', 'B04', 'B05', 'C01', 'C02', 'C03', 'C04', 'C05']) {
      const n = await repo.completionCount(id);
      if (n) counts[id] = n;
    }
    setMoments(m); setAttachments(a); setBookmarks(b); setActiveSession(s); setPrefs(parsePrefs(p)); setCompletions(counts);
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { repository: repo, directory } = await openPrivateStore();
        if (cancelled) return;
        repoRef.current = repo;
        setRepository(repo); setPrivateDirectory(directory);
        await load(repo);
      } catch {
        // The app still opens: conversations are bundled and never depend on storage (spec 20/65).
        setStorageError('Private storage is unavailable on this device right now.');
      } finally {
        if (!cancelled) setReady(true);
      }
    })();
    return () => { cancelled = true; };
  }, [load]);

  const repo = () => {
    if (!repoRef.current) throw new Error('This could not be saved yet. Private storage is unavailable.');
    return repoRef.current;
  };
  const refresh = useCallback(async () => { if (repoRef.current) await load(repoRef.current); }, [load]);

  const setPref = useCallback(async <K extends keyof Prefs>(key: K, value: Prefs[K]) => {
    setPrefs(previous => ({ ...previous, [key]: value }));
    if (repoRef.current) await repoRef.current.setPreference(key, JSON.stringify(value));
  }, []);

  const language: Language = prefs.language === 'system' ? deviceLanguage() : prefs.language;

  const value = useMemo<Store>(() => ({
    ready, storageError, repository, privateDirectory, prefs, language, setPref, moments, attachments, bookmarks, completions, activeSession,
    entitlement, setEntitlement, refresh,

    async startSession(topicId, topicVersion) {
      const session: ActiveSession = { sessionId: uuid.v4(), topicId, topicVersion, position: 0, nudgeShown: false, language, startedAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
      if (repoRef.current) await repoRef.current.saveActiveSession(session);
      setActiveSession(session);
      return session;
    },
    async saveSession(session) {
      setActiveSession(session);
      if (repoRef.current) await repoRef.current.saveActiveSession(session);
    },
    async finishSession(sessionId, topicId) {
      if (repoRef.current) {
        const counted = await repoRef.current.recordCompletion(sessionId, topicId);
        if (counted) setCompletions(c => ({ ...c, [topicId]: (c[topicId] ?? 0) + 1 }));
      }
      setActiveSession(s => (s?.sessionId === sessionId ? null : s));
    },
    async dismissResume() {
      if (repoRef.current) await repoRef.current.clearActiveSession();
      setActiveSession(null);
    },

    async saveMoment(input) {
      const saved = await repo().saveMoment({ ...input, id: input.id ?? uuid.v4() });
      setMoments(await repo().listMoments());
      return saved;
    },
    async updateMoment(id, expectedVersion, changes) {
      const updated = await repo().updateMoment(id, expectedVersion, changes);
      setMoments(await repo().listMoments());
      return updated;
    },
    async deleteMoment(id) {
      const files = (await repo().listAttachments(id));
      await repo().deleteMoment(id);
      for (const a of files) deleteFileQuietly(fileUri(privateDirectory, a.relativePath));
      setMoments(await repo().listMoments());
      setAttachments(await repo().listAttachments());
    },
    async attachAudio(momentId, sourceUri, durationMs) {
      if (!privateDirectory) throw new Error('This could not be saved yet.');
      const id = uuid.v4();
      const extension = sourceUri.split('.').pop()?.split('?')[0] || 'm4a';
      const relativePath = `audio/${id}.${extension}`;
      const folder = new Directory(`file://${privateDirectory}/audio`);
      if (!folder.exists) folder.create({ intermediates: true, idempotent: true });
      const source = new File(sourceUri);
      const target = new File(fileUri(privateDirectory, relativePath));
      source.copySync(target);
      await repo().addAttachment({ id, momentId, kind: 'audio', relativePath, bytes: target.size ?? 0, durationMs });
      deleteFileQuietly(sourceUri);
      setAttachments(await repo().listAttachments());
    },
    async removeAttachment(attachment) {
      await repo().deleteAttachment(attachment.id);
      deleteFileQuietly(fileUri(privateDirectory, attachment.relativePath));
      setAttachments(await repo().listAttachments());
    },
    attachmentUri: attachment => fileUri(privateDirectory, attachment.relativePath),
    async toggleBookmark(topicId) {
      const on = !bookmarks.includes(topicId);
      setBookmarks(b => (on ? [topicId, ...b] : b.filter(id => id !== topicId)));
      if (repoRef.current) await repoRef.current.setBookmark(topicId, on);
    },
    async deleteAllPrivateContent() {
      await repo().deleteAllPrivateContent();
      if (privateDirectory) {
        const audio = new Directory(`file://${privateDirectory}/audio`);
        try { if (audio.exists) audio.delete(); } catch { /* removed at next cleanup */ }
      }
      await load(repo());
    },
  }), [ready, storageError, repository, privateDirectory, prefs, language, setPref, moments, attachments, bookmarks, completions, activeSession, entitlement, refresh, load]);

  return <Context.Provider value={value}>{children}</Context.Provider>;
}

function fileUri(directory: string | null, relativePath: string) {
  return `file://${directory ?? ''}/${relativePath}`;
}
function deleteFileQuietly(uri: string) {
  try { const f = new File(uri); if (f.exists) f.delete(); } catch { /* best effort; never logs content */ }
}

export function useAppStore() {
  const value = useContext(Context);
  if (!value) throw new Error('useAppStore requires AppStoreProvider');
  return value;
}
