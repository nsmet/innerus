import React, { useState } from 'react';
import { View } from 'react-native';
import { topics } from '../content/catalogue';
import { SceneArt, chapterFocus } from '../design/Art';
import { EmptyState, MomentRow, TopicRow } from '../design/patterns';
import { BackHeader, Button, Chip, CloseHeader, Eyebrow, IconButton, ListGroup, ListRow, Screen, SearchField, Sheet, StatusLine, TextBlock, ToggleRow, Toolbar, WarmCard } from '../design/primitives';
import { useDesign } from '../design/ThemeProvider';
import { colors, spacing } from '../design/tokens';
import { useAppStore } from '../state/AppStore';
import type { StackProps } from '../navigation/types';

/**
 * Local component gallery (development builds only). The SAME components the app uses, with fictional
 * fixtures. Nothing here records, saves, buys or reads the private library.
 */
export function GalleryScreen({ navigation }: StackProps<'Gallery'>) {
  const { palette, language, scheme } = useDesign();
  const { setPref } = useAppStore();
  const [query, setQuery] = useState('');
  const [toggle, setToggle] = useState(true);
  const [sheet, setSheet] = useState(false);
  const [presses, setPresses] = useState(0);
  const press = () => setPresses(n => n + 1);
  const topic = topics[0];
  const fixtureMoment = { id: 'fixture', topicId: 'A01', topicVersion: '1.0', promptId: 'A01-03', questionSnapshot: topic.prompts[2].text.en, contentLanguage: 'en' as const,
    title: 'The first coffee', body: 'Fictional: that first coffee. The nerves. How easily we started talking.', source: 'typed' as const, participantLabel: null, version: 1, createdAt: '2026-10-21T19:00:00Z', updatedAt: '2026-10-21T19:00:00Z' };
  return <Screen testID="gallery-screen" header={<BackHeader label="InnerUs · Development" onBack={() => navigation.canGoBack() ? navigation.goBack() : navigation.replace('Main')} />}>
    <TextBlock variant="display">Component gallery</TextBlock>
    <TextBlock secondary>Shared tokens and components used by the app. Fictional fixtures only. Actions pressed: {presses}</TextBlock>
    <View style={{ flexDirection: 'row', gap: spacing.sm, flexWrap: 'wrap' }}>
      <Chip label={language === 'en' ? 'Nederlands' : 'English'} onPress={() => void setPref('language', language === 'en' ? 'nl' : 'en')} />
      <Chip label={scheme === 'light' ? 'Dark' : 'Light'} onPress={() => void setPref('appearance', scheme === 'light' ? 'dark' : 'light')} />
    </View>
    <Eyebrow>Foundations · colour roles</Eyebrow>
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>{Object.entries(colors[scheme]).map(([name, value]) => <View key={name} style={{ width: 96, gap: 4 }}><View style={{ height: 32, borderRadius: 6, backgroundColor: value, borderWidth: 1, borderColor: palette.divider }} /><TextBlock variant="supporting">{name}</TextBlock></View>)}</View>
    <Eyebrow>DS03 · Text</Eyebrow>
    <TextBlock variant="display">Where shall we go tonight?</TextBlock>
    <TextBlock variant="title">Our first date</TextBlock>
    <TextBlock variant="invitation" secondary>A little trip back to the beginning.</TextBlock>
    <TextBlock variant="prompt">{topic.prompts[2].text[language]}</TextBlock>
    <Eyebrow framed>The little details</Eyebrow>
    <Eyebrow>DS04 · Actions</Eyebrow>
    <Button label="Start this conversation" trailingArrow onPress={press} />
    <Button label="Saving…" loading loadingLabel="Saving…" onPress={press} />
    <Button label="Choose a topic first" disabled reason="Disabled with a reason" onPress={press} />
    <Button variant="secondary" icon="pen" label="Keep a moment" onPress={press} />
    <Button variant="quiet" icon="chevronDown" label="A little nudge?" onPress={press} />
    <Button variant="destructive" icon="trash" label="Delete this moment" onPress={press} />
    <Eyebrow>DS05–DS07 · Icons, search, filters</Eyebrow>
    <View style={{ flexDirection: 'row' }}><IconButton name="settings" label="Settings" onPress={press} /><IconButton name="close" label="Close" onPress={press} /><IconButton name="bookmark" label="Save" onPress={press} /><IconButton name="bookmark" filled label="Saved" onPress={press} /><IconButton name="share" label="Share" onPress={press} /></View>
    <SearchField value={query} onChangeText={setQuery} placeholder="Find a conversation" clearLabel="Clear search" />
    <View style={{ flexDirection: 'row', gap: spacing.sm, flexWrap: 'wrap' }}><Chip selected label="All themes" onPress={press} /><Chip label="Our story" onPress={press} /><Chip menu label="Any length" onPress={press} /></View>
    <Eyebrow>DS08 · Topic row</Eyebrow>
    <TopicRow topic={topic} owned={false} bookmarked onOpen={press} onToggleBookmark={press} />
    {topics[3] && <TopicRow topic={topics[3]} owned={false} bookmarked={false} onOpen={press} onToggleBookmark={press} />}
    <Eyebrow>DS10 · Scene, chapters</Eyebrow>
    {chapterFocus.slice(0, 3).map((focus, i) => <SceneArt key={i} family="cafe" height={120} focus={focus} />)}
    <Eyebrow>DS11 · Conversation</Eyebrow>
    <CloseHeader title="Our first date" closeLabel="Close" onClose={press} />
    <Toolbar actions={[{ icon: 'back', label: 'Previous', onPress: press }, { icon: 'skip', label: 'Skip', onPress: press }, { icon: 'pen', label: 'Keep a moment', onPress: press }]} />
    <Eyebrow>DS14 · Moment</Eyebrow>
    <MomentRow moment={fixtureMoment} attachments={[]} onOpen={press} />
    <Eyebrow>DS19 · Status</Eyebrow>
    <StatusLine icon="device" text="Saved on this device" /><StatusLine icon="cloud" text="Waiting to sync" /><StatusLine icon="warning" text="This could not be saved yet. Your draft is still here." />
    <Eyebrow>DS20 · Empty state</Eyebrow>
    <EmptyState title="Your saved moments will gather here." detail="Fictional preview; no personal library is read." action={{ label: 'Find a conversation', onPress: press }} />
    <Eyebrow>DS21 · Preferences</Eyebrow>
    <ListGroup title="Example"><ToggleRow title="Keep the original audio" value={toggle} onChange={setToggle} onLabel="On" offLabel="Off" /><ListRow icon="globe" title="App language" value="Follow device" onPress={press} /></ListGroup>
    <WarmCard><TextBlock variant="meta">App lock is unavailable. Set a passcode on this device first.</TextBlock></WarmCard>
    <Eyebrow>DS22 · Sheet</Eyebrow>
    <Button variant="secondary" label="Open a sheet" onPress={() => setSheet(true)} />
    <Sheet visible={sheet} onClose={() => setSheet(false)}><TextBlock variant="title">A little piece of us.</TextBlock><TextBlock secondary>Fictional sheet.</TextBlock><Button label="Done" onPress={() => setSheet(false)} /></Sheet>
  </Screen>;
}
