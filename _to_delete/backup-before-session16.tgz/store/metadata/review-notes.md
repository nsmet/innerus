# App Review notes — InnerUs 2.0.0 (com.nicksmet.innerus)

Paste the block below into App Store Connect › App Review Information › Notes. Sign-in information: leave "Sign-in required" unchecked.

---

Thank you for reviewing InnerUs 2.0. This version is a complete rebuild of the existing app.

NO ACCOUNT
The app has no account, sign-in or registration of any kind. Earlier versions (1.x) used Firebase sign-in with Google/Apple; that is removed. There is no backend: no analytics, no tracking, no ads. All content (15 conversations, English and Dutch) is bundled in the app.

PURCHASES (StoreKit, no subscription)
- Three conversations are always free: Our first date, An ordinary Tuesday, A Saturday of our own.
- com.nicksmet.innerus.trial7 "InnerUs 7-day free trial" is a €0.00 non-consumable (guideline 3.1.1 free-trial pattern). It unlocks all 15 conversations for 7 days, counted from the purchase date of this item. Nothing is charged and nothing renews; after 7 days the 12 extra conversations lock again.
- com.nicksmet.innerus.collection "InnerUs Full Collection" is a €9.99 non-consumable that keeps all conversations permanently.
- Restore purchases is on the offer screen.
- Earlier 1.x subscribers keep access until their subscription ends; the 2.0 What's New text tells them how to switch off renewal.

How to test:
1. Open the app and dismiss or complete the short introduction.
2. On Tonight, start "Our first date" (free) to see a full conversation.
3. Open any locked conversation in Explore (for example "A place we would go back to") or tap the offer card on Tonight. The offer screen explains the free week before it starts.
4. Tap "Start your free week" and confirm the €0.00 purchase with a sandbox account. All conversations open.
5. Or tap "Or buy once for €9.99" to test the one-time purchase. "Restore purchases" restores either item.

RECORDING, ON-DEVICE SPEECH AND SUMMARIES
- The microphone is used only after the user explicitly taps Record while keeping a Moment. There is no background or automatic listening.
- On supported iPhones, speech-to-text and the draft summary run fully on the device ([FRAMEWORKS: e.g. on-device SFSpeechRecognizer with requiresOnDeviceRecognition + Apple Foundation Models — confirm]). Audio and text are never sent to a server. The user reviews the draft before anything is saved.
- On devices without on-device support (or with Apple Intelligence off), the app shows a manual path: the recording is kept as a voice note and the user types the note.
- Minimum for on-device features: [DEVICE / iOS REQUIREMENTS — confirm, e.g. iPhone 15 Pro or later, iOS 26].

iCLOUD (OPTIONAL)
Moments are stored locally. Users can optionally turn on sync to their own private iCloud (CloudKit private database). The app works fully with iCloud off or signed out.

OTHER
- Face ID is used only for the optional app lock.
- Export and delete-all are in Settings.
- iPhone only in this release.

Contact: Nick Smet, [SUPPORT EMAIL], [PHONE]
