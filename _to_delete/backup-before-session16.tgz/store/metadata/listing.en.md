# InnerUs 2.0 — App Store listing (English, en-US / en-GB)

Character counts verified by script (keywords in bytes). Placeholders in [BRACKETS].

## App name  (30/30)

InnerUs: Questions for Couples

Options considered: “InnerUs: Questions for Couples” (30); “InnerUs: Couple Conversations” (29); “InnerUs – Talk as a Couple” (26)

## Subtitle  (24/30)

Ten-minute talks for two

Options considered: “Ten-minute talks for two” (24); “Illustrated talks for two” (25); “Talk tonight, just you two” (26)

## Promotional text  (162/170)

Fifteen illustrated conversations for the two of you. No account, and everything stays on your phone. Three are free, a free week opens the rest, then €9.99 once.

## Keywords  (98/100 bytes)

relationship,partner,date,night,love,marriage,conversation,starters,deep,intimacy,boyfriend,spouse

## Description  (2387/4000)

InnerUs gives the two of you a conversation for tonight. Put the phone between you, read the question out loud and talk. A conversation takes about ten minutes, and nothing counts down.

HOW IT WORKS
• Start the conversation that is ready on Tonight, or pick one yourself.
• Five questions build like a story, each with its own watercolour painting.
• Stuck? Open a nudge for an angle or a few examples. Or skip the question.
• A closing question asks what you want to remember.
• No time for a whole conversation? Ask for one quick question.

WHAT YOU TALK ABOUT
15 conversations in three themes:
• Our story: your first date, a trip you still talk about, how your rituals began.
• Us today: an ordinary Tuesday, what helps you unwind, the things that make you laugh.
• What's next: a Saturday of your own, a dream you keep postponing, something new to try together.

The questions ask about real things: a day, a place, a habit, something one of you said. They never assume how long you have been together, whether you are married or whether you have children. There are no scores, no tests and no streaks. InnerUs is not therapy. It is a good reason to talk.

KEEP WHAT MATTERS (OPTIONAL)
Save a moment from any conversation: a typed note, or a voice recording of an answer. On supported iPhones, InnerUs can turn a recording into text and suggest a short summary, entirely on your iPhone. You check it before anything is saved. On other iPhones you simply write the note yourself.

PRIVATE BY DESIGN
• No account, no sign-in, no email address.
• No analytics, no tracking, no ads.
• Everything stays on your iPhone. We run no server that stores your conversations.
• Optional sync through your own private iCloud.
• Lock the app with Face ID.
• Export everything, or delete it all, whenever you want.

WHAT IT COSTS
• Three conversations are free for good: Our first date, An ordinary Tuesday and A Saturday of our own. Quick questions are free too.
• Want to try the rest? Start your free week with one tap. All 15 conversations open, nothing is charged and the week ends by itself.
• Keep all 15 with one payment of €9.99 (or the equivalent in your currency). No subscription. Nothing renews.
• Recording, Moments, iCloud sync and export are never behind a payment.
• New conversations arrive from time to time as free updates.

Privacy policy: [PRIVACY URL]
Support: [SUPPORT URL]

## What's New in 2.0  (759/4000)

InnerUs 2.0 is completely rebuilt.

• No account anymore. Everything now lives on your iPhone, with optional sync through your own iCloud.
• 15 new illustrated conversations, each with its own paintings.
• The subscription is gone. Three conversations stay free, a free week opens the rest, and one payment of €9.99 keeps them for good.

Still subscribed? You keep full access until your subscription ends. You won't need it anymore, so turn off renewal in Settings › Apple Account › Subscriptions.

Your progress and the notes you wrote in the previous version were stored in your online account. They don't come along to this version.

[Optional: Want a copy of the notes you wrote in the previous version? Email [SUPPORT EMAIL] and we'll send them to you.]

## In-app purchases

- **Collection · display name** (23/30): InnerUs Full Collection
- **Collection · description** (37/45): 12 more conversations, yours for good
- **Free trial (€0 non-consumable) · display name** (24/30): InnerUs 7-day free trial
- **Free trial · description** (35/45): Every conversation, free for a week

## Screenshot captions (iPhone 6.9″ / 6.5″, same on Google Play)

1. **Ten minutes for the two of you** — Pick a conversation and talk. No timer, no scores, no streaks.
2. **Questions you’ll want to answer** — Five questions per conversation, each with its own painting.
3. **Stuck? Open a nudge.** — An optional hint helps you answer. Skip whenever you like.
4. **Five questions, one story** — From the nerves before to the way home, each with its own painting.
5. **15 conversations, three themes** — Our story, Us today and What’s next. New ones arrive over time.
6. **Keep what you want to remember** — Type a note or record your voice. On supported iPhones, a draft summary is made on the device.
7. **No account. It stays on your phone.** — No sign-up, no tracking, no analytics. Optional sync with your own iCloud.
8. **3 free. Then €9.99, once.** — Try all 15 conversations free for a week. No subscription.

## Google Play

### Title  (30/30)

InnerUs: Questions for Couples

### Short description  (76/80)

Illustrated ten-minute conversations for couples. No account. Fully private.

### Full description  (2088/4000)

InnerUs gives the two of you a conversation for tonight. Put the phone between you, read the question out loud and talk. A conversation takes about ten minutes, and nothing counts down.

HOW IT WORKS
• Start the conversation that is ready on Tonight, or pick one yourself.
• Five questions build like a story, each with its own watercolour painting.
• Stuck? Open a nudge for an angle or a few examples. Or skip the question.
• A closing question asks what you want to remember.
• No time for a whole conversation? Ask for one quick question.

WHAT YOU TALK ABOUT
15 conversations in three themes:
• Our story: your first date, a trip you still talk about, how your rituals began.
• Us today: an ordinary Tuesday, what helps you unwind, the things that make you laugh.
• What's next: a Saturday of your own, a dream you keep postponing, something new to try together.

The questions ask about real things: a day, a place, a habit, something one of you said. They never assume how long you have been together, whether you are married or whether you have children. There are no scores, no tests and no streaks. InnerUs is not therapy. It is a good reason to talk.

KEEP WHAT MATTERS (OPTIONAL)
Save a moment from any conversation: a typed note, or a voice recording of an answer.

PRIVATE BY DESIGN
• No account, no sign-in, no email address.
• No analytics, no tracking, no ads.
• Everything stays on your phone. We run no server that stores your conversations.
• Export everything, or delete it all, whenever you want.

WHAT IT COSTS
• Three conversations are free for good: Our first date, An ordinary Tuesday and A Saturday of our own. Quick questions are free too.
• Want to try the rest? Start your free week with one tap. All 15 conversations open, nothing is charged and the week ends by itself.
• Keep all 15 with one payment of €9.99 (or the equivalent in your currency). No subscription. Nothing renews.
• Recording, Moments and export are never behind a payment.
• New conversations arrive from time to time as free updates.

Privacy policy: [PRIVACY URL]
Support: [SUPPORT URL]

## Category and age rating

- Primary: **Lifestyle** · Secondary: **Entertainment**. Lifestyle is where couple and relationship apps are browsed and fits a calm evening ritual. Health & Fitness is the usual alternative (Paired, Lasting), but it frames the app as wellness/therapy, which InnerUs explicitly is not. Entertainment as secondary matches conversation cards and quick questions without that framing. If Nick wants maximum browse exposure next to Paired, swap the secondary to Health & Fitness.
- Age rating: **4+**. Questions are about dates, trips, habits and plans; the most intimate words are “laugh, or blush”. No romance-explicit, sexual, alcohol or medical content, no sharing, no web view. The questionnaire therefore yields 4+. Optional: Apple lets you set a higher minimum age; 13+ would signal the adult-couple audience but narrows Family Sharing reach. Recommended: keep 4+.
- Google Play: Everyone / PEGI 3 / USK 0 expected (no violence, sexual content, gambling, user interaction or location sharing).

## URLs

- Support URL: [SUPPORT URL]
- Privacy policy URL: [PRIVACY URL]
