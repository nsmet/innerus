# InnerUs 2.0 — App Store listing (Nederlands, nl-NL)

Character counts verified by script (keywords in bytes). Placeholders in [BRACKETS].

## App name  (28/30)

InnerUs: Vragen voor koppels

Options considered: “InnerUs: Vragen voor koppels” (28); “InnerUs: Praten met je lief” (27); “InnerUs: Praten als koppel” (26)

## Subtitle  (29/30)

Tien minuten voor jullie twee

Options considered: “Tien minuten voor jullie twee” (29); “Geïllustreerde gesprekken” (25); “Even samen praten, vanavond” (27)

## Promotional text  (168/170)

Vijftien geïllustreerde gesprekken voor jullie twee. Geen account, alles blijft op je telefoon. Drie zijn gratis, een gratis week opent de rest, daarna eenmalig € 9,99.

## Keywords  (95/100 bytes)

relatie,partner,koppel,stel,liefde,date,gesprek,gespreksstarters,diepgang,vriend,vriendin,samen

## Description  (2518/4000)

InnerUs geeft jullie twee een gesprek voor vanavond. Leg je telefoon tussen jullie in, lees de vraag hardop en praat. Een gesprek duurt ongeveer tien minuten, en er loopt geen klok mee.

ZO WERKT HET
• Begin het gesprek dat klaarstaat onder Vanavond, of kies er zelf een.
• Vijf vragen bouwen op als een verhaal, elk met een eigen aquarel.
• Even vast? Open een zetje voor een invalshoek of een paar voorbeelden. Of sla de vraag over.
• Een slotvraag gaat over wat je wilt onthouden.
• Geen tijd voor een heel gesprek? Vraag één snelle vraag.

WAAROVER JE PRAAT
15 gesprekken in drie thema's:
• Ons verhaal: jullie eerste date, een reis waar jullie nog over praten, hoe jullie rituelen begonnen.
• Wij vandaag: een gewone dinsdag, wat je helpt ontspannen, de dingen waar jullie om lachen.
• Wat komt er nog: een zaterdag voor jullie, een droom die jullie blijven uitstellen, samen iets nieuws proberen.

De vragen gaan over echte dingen: een dag, een plek, een gewoonte, iets wat een van jullie zei. Ze gaan er nooit van uit hoelang jullie samen zijn, of jullie getrouwd zijn of kinderen hebben. Er zijn geen scores, geen tests en geen reeksen om vol te houden. InnerUs is geen therapie. Het is een goede reden om te praten.

BEWAAR WAT TELT (OPTIONEEL)
Bewaar een moment uit elk gesprek: een getypte notitie, of een spraakopname van een antwoord. Op ondersteunde iPhones zet InnerUs een opname om in tekst en stelt het een korte samenvatting voor, volledig op je iPhone. Jij kijkt alles na voor het bewaard wordt. Op andere iPhones schrijf je de notitie gewoon zelf.

PRIVÉ VAN BIJ HET BEGIN
• Geen account, niet inloggen, geen e-mailadres.
• Geen analytics, geen tracking, geen advertenties.
• Alles blijft op je iPhone. Wij hebben geen server die je gesprekken bewaart.
• Optioneel synchroniseren via je eigen privé-iCloud.
• Vergrendel de app met Face ID.
• Exporteer alles, of wis alles, wanneer je wilt.

WAT HET KOST
• Drie gesprekken blijven altijd gratis: Onze eerste date, Een gewone dinsdag en Een zaterdag voor ons. Snelle vragen zijn ook gratis.
• Wil je de rest proberen? Start je gratis week met één tik. Alle 15 gesprekken gaan open, er wordt niets aangerekend en de week stopt vanzelf.
• Hou alle 15 met één betaling van € 9,99 (of het bedrag in jouw munteenheid). Geen abonnement. Er wordt niets verlengd.
• Opnemen, Momenten, iCloud-synchronisatie en exporteren zitten nooit achter een betaling.
• Af en toe komen er gratis nieuwe gesprekken bij.

Privacybeleid: [PRIVACY URL]
Support: [SUPPORT URL]

## What's New in 2.0  (776/4000)

InnerUs 2.0 is helemaal opnieuw gebouwd.

• Geen account meer. Alles staat nu op je iPhone, met optioneel synchroniseren via je eigen iCloud.
• 15 nieuwe geïllustreerde gesprekken, elk met eigen schilderijen.
• Het abonnement verdwijnt. Drie gesprekken blijven gratis, een gratis week opent de rest en met één betaling van € 9,99 hou je ze voor altijd.

Heb je nog een abonnement? Dan hou je volledige toegang tot het afloopt. Je hebt het niet meer nodig, dus zet verlengen uit via Instellingen › Apple-account › Abonnementen.

Je voortgang en de notities uit de vorige versie stonden in je online account. Die gaan niet mee naar deze versie.

[Optioneel: Wil je een kopie van de notities die je in de vorige versie schreef? Mail naar [SUPPORT EMAIL] en we sturen ze je door.]

## In-app purchases

- **Collection · display name** (27/30): InnerUs volledige collectie
- **Collection · description** (40/45): 12 extra gesprekken, voor altijd van jou
- **Free trial (€0 non-consumable) · display name** (22/30): InnerUs 7 dagen gratis
- **Free trial · description** (28/45): Elk gesprek, een week gratis

## Screenshot captions (iPhone 6.9″ / 6.5″, same on Google Play)

1. **Tien minuten voor jullie twee** — Kies een gesprek en praat. Geen timer, geen scores, niets om bij te houden.
2. **Vragen die je echt wilt beantwoorden** — Vijf vragen per gesprek, elk met een eigen schilderij.
3. **Even vast? Open een zetje.** — Een optionele hint helpt je op weg. Overslaan mag altijd.
4. **Vijf vragen, één verhaal** — Van de zenuwen vooraf tot de weg naar huis, elk met een eigen schilderij.
5. **15 gesprekken, drie thema’s** — Ons verhaal, Wij vandaag en Wat komt er nog. Af en toe komt er een nieuw gesprek bij.
6. **Bewaar wat je wilt onthouden** — Typ een notitie of spreek ze in. Op ondersteunde iPhones maakt je iPhone zelf een eerste samenvatting.
7. **Geen account. Alles blijft bij jou.** — Geen registratie, geen tracking, geen analytics. Optioneel synchroniseren met je eigen iCloud.
8. **3 gratis. Daarna eenmalig €9,99.** — Probeer alle 15 gesprekken een week gratis. Geen abonnement.

## Google Play

### Title  (28/30)

InnerUs: Vragen voor koppels

### Short description  (77/80)

Geïllustreerde gesprekken van tien minuten voor koppels. Geen account. Privé.

### Full description  (2190/4000)

InnerUs geeft jullie twee een gesprek voor vanavond. Leg je telefoon tussen jullie in, lees de vraag hardop en praat. Een gesprek duurt ongeveer tien minuten, en er loopt geen klok mee.

ZO WERKT HET
• Begin het gesprek dat klaarstaat onder Vanavond, of kies er zelf een.
• Vijf vragen bouwen op als een verhaal, elk met een eigen aquarel.
• Even vast? Open een zetje voor een invalshoek of een paar voorbeelden. Of sla de vraag over.
• Een slotvraag gaat over wat je wilt onthouden.
• Geen tijd voor een heel gesprek? Vraag één snelle vraag.

WAAROVER JE PRAAT
15 gesprekken in drie thema's:
• Ons verhaal: jullie eerste date, een reis waar jullie nog over praten, hoe jullie rituelen begonnen.
• Wij vandaag: een gewone dinsdag, wat je helpt ontspannen, de dingen waar jullie om lachen.
• Wat komt er nog: een zaterdag voor jullie, een droom die jullie blijven uitstellen, samen iets nieuws proberen.

De vragen gaan over echte dingen: een dag, een plek, een gewoonte, iets wat een van jullie zei. Ze gaan er nooit van uit hoelang jullie samen zijn, of jullie getrouwd zijn of kinderen hebben. Er zijn geen scores, geen tests en geen reeksen om vol te houden. InnerUs is geen therapie. Het is een goede reden om te praten.

BEWAAR WAT TELT (OPTIONEEL)
Bewaar een moment uit elk gesprek: een getypte notitie, of een spraakopname van een antwoord.

PRIVÉ VAN BIJ HET BEGIN
• Geen account, niet inloggen, geen e-mailadres.
• Geen analytics, geen tracking, geen advertenties.
• Alles blijft op je telefoon. Wij hebben geen server die je gesprekken bewaart.
• Exporteer alles, of wis alles, wanneer je wilt.

WAT HET KOST
• Drie gesprekken blijven altijd gratis: Onze eerste date, Een gewone dinsdag en Een zaterdag voor ons. Snelle vragen zijn ook gratis.
• Wil je de rest proberen? Start je gratis week met één tik. Alle 15 gesprekken gaan open, er wordt niets aangerekend en de week stopt vanzelf.
• Hou alle 15 met één betaling van € 9,99 (of het bedrag in jouw munteenheid). Geen abonnement. Er wordt niets verlengd.
• Opnemen, Momenten en exporteren zitten nooit achter een betaling.
• Af en toe komen er gratis nieuwe gesprekken bij.

Privacybeleid: [PRIVACY URL]
Support: [SUPPORT URL]

## Category and age rating

- Primary: **Lifestyle** · Secondary: **Entertainment**. Lifestyle is where couple and relationship apps are browsed and fits a calm evening ritual. Health & Fitness is the usual alternative (Paired, Lasting), but it frames the app as wellness/therapy, which InnerUs explicitly is not. Entertainment as secondary matches conversation cards and quick questions without that framing. If Nick wants maximum browse exposure next to Paired, swap the secondary to Health & Fitness.
- Age rating: **4+**. Questions are about dates, trips, habits and plans; the most intimate words are “laugh, or blush”. No romance-explicit, sexual, alcohol or medical content, no sharing, no web view. The questionnaire therefore yields 4+. Optional: Apple lets you set a higher minimum age; 13+ would signal the adult-couple audience but narrows Family Sharing reach. Recommended: keep 4+.
- Google Play: Everyone / PEGI 3 / USK 0 expected (no violence, sexual content, gambling, user interaction or location sharing).

## URLs

- Support URL: [SUPPORT URL]
- Privacy policy URL: [PRIVACY URL]
