import React from 'react';
import { View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useFonts } from 'expo-font';
import { AppStoreProvider, useAppStore } from './src/state/AppStore';
import { ThemeProvider } from './src/design/ThemeProvider';
import { AppNavigator } from './src/navigation/AppNavigator';
import { AppLockGate } from './src/features/AppLockGate';
import { AccessProvider } from './src/platform/access';
import { colors } from './src/design/tokens';
import { ErrorBoundary } from './src/features/ErrorBoundary';

function Root() {
  const { ready } = useAppStore();
  // Private storage opens in well under a second; the paper-coloured frame avoids a flash.
  if (!ready) return <View style={{ flex: 1, backgroundColor: colors.light.canvas }} />;
  return <AccessProvider><ThemeProvider><AppLockGate><AppNavigator /></AppLockGate></ThemeProvider></AccessProvider>;
}

export default function App() {
  const [loaded, error] = useFonts({
    SourceSerif4: require('./assets/fonts/SourceSerif4-Regular.ttf'),
    SourceSerif4Italic: require('./assets/fonts/SourceSerif4-Italic.ttf'),
  });
  if (!loaded && !error) return <View style={{ flex: 1, backgroundColor: colors.light.canvas }} />;
  return <SafeAreaProvider><ErrorBoundary><AppStoreProvider><Root /></AppStoreProvider></ErrorBoundary></SafeAreaProvider>;
}
